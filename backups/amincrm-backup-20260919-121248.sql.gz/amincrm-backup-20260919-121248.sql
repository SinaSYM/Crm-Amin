--
-- PostgreSQL database dump
--

\restrict OyOzujgOSvEwVFhWvBYvyWJcVO84oBtT1aRRTFNr7dMQMwmR5yjavatAxsd59rX

-- Dumped from database version 18.6 (6569466)
-- Dumped by pg_dump version 18.6 (Ubuntu 18.6-1.pgdg22.04+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CommissionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CommissionStatus" AS ENUM (
    'PENDING',
    'APPROVED',
    'PAID'
);


--
-- Name: InteractionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InteractionType" AS ENUM (
    'CALL',
    'NOTE',
    'SYSTEM'
);


--
-- Name: LeadStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LeadStatus" AS ENUM (
    'NEW',
    'CONTACTED',
    'IN_PROGRESS',
    'CONVERTED'
);


--
-- Name: PaymentItemStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentItemStatus" AS ENUM (
    'PENDING',
    'PAID',
    'OVERDUE'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PAID',
    'INSTALLMENT'
);


--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentType" AS ENUM (
    'FULL',
    'INSTALLMENT'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'ADMIN',
    'SALES_MANAGER',
    'SALES_AGENT',
    'STUDENT',
    'EDUCATION_OFFICER',
    'FINANCIAL_OFFICER',
    'MENTOR',
    'DEPT_MANAGER'
);


--
-- Name: UserScope; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserScope" AS ENUM (
    'STANDARD',
    'GLOBAL'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Account; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Account" (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- Name: ActivityLog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ActivityLog" (
    id text NOT NULL,
    user_id text NOT NULL,
    user_name text NOT NULL,
    user_role text NOT NULL,
    action text NOT NULL,
    description text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ClassSession; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ClassSession" (
    id text NOT NULL,
    course_id text NOT NULL,
    title text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    link text,
    archive_url text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Commission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Commission" (
    id text NOT NULL,
    referrer_id text NOT NULL,
    referee_lead_id text NOT NULL,
    amount double precision NOT NULL,
    status public."CommissionStatus" DEFAULT 'PENDING'::public."CommissionStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Course; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Course" (
    id text NOT NULL,
    title text NOT NULL,
    price double precision DEFAULT 0 NOT NULL,
    capacity integer DEFAULT 30 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    department text
);


--
-- Name: Enrollment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Enrollment" (
    id text NOT NULL,
    student_id text NOT NULL,
    course_id text NOT NULL,
    payment_status public."PaymentStatus" DEFAULT 'PAID'::public."PaymentStatus" NOT NULL,
    enrollment_date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Interaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Interaction" (
    id text NOT NULL,
    lead_id text NOT NULL,
    agent_id text NOT NULL,
    interaction_type public."InteractionType" DEFAULT 'NOTE'::public."InteractionType" NOT NULL,
    content text NOT NULL,
    next_followup_date timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Lead; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Lead" (
    id text NOT NULL,
    phone_number text NOT NULL,
    first_name text DEFAULT ''::text NOT NULL,
    last_name text DEFAULT ''::text NOT NULL,
    source text DEFAULT 'manual'::text NOT NULL,
    status public."LeadStatus" DEFAULT 'NEW'::public."LeadStatus" NOT NULL,
    score integer DEFAULT 0 NOT NULL,
    segment text DEFAULT 'NORMAL'::text NOT NULL,
    notes text DEFAULT ''::text NOT NULL,
    assigned_to_id text,
    referred_by_id text,
    target_course_id text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    department text
);


--
-- Name: PasswordResetToken; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PasswordResetToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: Payment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Payment" (
    id text NOT NULL,
    enrollment_id text NOT NULL,
    amount double precision NOT NULL,
    payment_type public."PaymentType" DEFAULT 'FULL'::public."PaymentType" NOT NULL,
    status public."PaymentItemStatus" DEFAULT 'PENDING'::public."PaymentItemStatus" NOT NULL,
    due_date timestamp(3) without time zone NOT NULL,
    paid_date timestamp(3) without time zone,
    description text DEFAULT ''::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    check_number text,
    check_bank text,
    check_date timestamp(3) without time zone,
    check_status text
);


--
-- Name: PurchaseRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PurchaseRequest" (
    id text NOT NULL,
    requester_id text NOT NULL,
    item_name text NOT NULL,
    amount double precision NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- Name: SignupRequest; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SignupRequest" (
    id text NOT NULL,
    email text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    phone_number text NOT NULL,
    desired_department text,
    "passwordHash" text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    reviewed_by_id text,
    reviewed_at timestamp(3) without time zone,
    review_note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Task; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Task" (
    id text NOT NULL,
    agent_id text NOT NULL,
    lead_id text,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    due_date timestamp(3) without time zone NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    reminder_time integer,
    reminder_sent boolean DEFAULT false NOT NULL
);


--
-- Name: Teacher; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Teacher" (
    id text NOT NULL,
    name text NOT NULL,
    phone_number text NOT NULL,
    email text,
    specialty text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: Ticket; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."Ticket" (
    id text NOT NULL,
    student_id text NOT NULL,
    title text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: User; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."User" (
    id text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    phone_number text NOT NULL,
    role public."UserRole" DEFAULT 'SALES_AGENT'::public."UserRole" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    referral_code text,
    wallet_balance double precision DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    department text,
    personal_notes text DEFAULT ''::text NOT NULL,
    admin_notes text DEFAULT ''::text NOT NULL,
    email text,
    "passwordHash" text,
    scope public."UserScope" DEFAULT 'STANDARD'::public."UserScope" NOT NULL,
    "isApproved" boolean DEFAULT false NOT NULL
);


--
-- Data for Name: Account; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Account" (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- Data for Name: ActivityLog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ActivityLog" (id, user_id, user_name, user_role, action, description, "createdAt") FROM stdin;
cmt1d05xt003cxvhldazjpeis	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	USER_CREATE	کاربر جدید فاطمه یعقوبی تعریف شد.	2026-08-20 10:10:06.737
cmt1d05yx003dxvhlpphkrkg7	cmt1d04oo0008xvhldysumsj2	فاطمه یعقوبی	EDUCATION_OFFICER	COURSE_CREATE	دوره جدید مدیریت پروژه ایجاد شد.	2026-08-20 10:10:06.777
cmt457xbw0002xvcv1cuhtisp	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 08:55:30.429
cmt45evh20002ju046wmulc2o	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 09:00:54.614
cmt45fyfl0002l1049ui782uk	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 09:01:45.105
cmt4a1l060002l804p9b5whyv	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:10:32.599
cmt4a7sc10002xvg4gukj6wvd	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:15:22.034
cmt4acby60002ld04zgsroftf	cmt1d04qb000bxvhl72gu91dh	نجیبه رمضان‌زاده	DEPT_MANAGER	LOGIN	User logged in (DEPT_MANAGER)	2026-08-22 11:18:54.079
cmt4ahjpn0002if04n0wlcqg6	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:22:57.419
cmt4ao7dv0002xvecurhg7sps	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:28:08.036
cmt4aod810005xvecw12ty2lu	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:28:15.601
cmt4awbtn0006ld0418vne93l	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:34:27.036
cmt4b184n0001xvm54x0k3rce	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "تست کاربر" (test@example.com) as SALES_AGENT	2026-08-22 11:38:15.528
cmt4b6xt10001l404w7k4nf52	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "سینا میثمی" (sinameysami8@gmail.com) as SALES_AGENT	2026-08-22 11:42:42.086
cmt4b745p0007ld04vb2yjjn0	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	REJECT_SIGNUP	Rejected signup request for "تست2 کاربر2" (pending-1787398121588@placeholder.local)	2026-08-22 11:42:50.318
cmt4b7m3d000ald04twv9c2xn	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-22 11:43:13.561
cmt4b8tw9000dld041g5psiuw	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:44:10.329
cmt4bk55q0002xvf8f7e4j5ho	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:52:58.143
cmt4bm9ck0004l404aeshqnfp	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 11:54:36.884
cmt4bnj970008ig04f2xho217	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-22 11:55:36.38
cmt4bom7c0008l104vg03g8ir	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	CREATE_LEAD	Created lead "Sina Meysami" (Phone: 09158459005)	2026-08-22 11:56:26.856
cmt4bomnf000hl10431awrvj7	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	CREATE_LEAD	Created lead "Sina Meysami" (Phone: 09158459005)	2026-08-22 11:56:27.435
cmt4bvi0l0002xv8gunlr1z2v	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 12:01:48.021
cmt4bzkv50006xv8g0w0oi5ar	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_LEAD_STATUS	Changed status of lead "آرش ملکی" from CONVERTED to IN_PROGRESS	2026-08-22 12:04:58.337
cmt4bzlry000fxv8g6ptjo54l	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_LEAD	Created lead "تست دکباگ" (Phone: 09359999999)	2026-08-22 12:04:59.518
cmt4c5id50002xvx8hmhm1zua	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 12:09:35.034
cmt4c99hc0002l804ezfda7zh	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-22 12:12:30.144
cmt4c9xln0005l8047856b0eg	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 12:13:01.403
cmt4cmbvo0007l404vavy25nb	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-22 12:22:39.78
cmt4cqugp0002xvnzmbmorlx0	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 12:26:10.489
cmt4crlw70005xvnzhhnqmyei	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 12:26:46.039
cmt4cstz30008xvnzgtyravqx	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-22 12:27:43.168
cmt4csv31000hxvnzttjzv0pz	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_LEAD	Created lead "test_del lead" (Phone: 09990000001)	2026-08-22 12:27:44.605
cmt4cswh5000ixvnza10jcrn7	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_LEAD	Deleted lead "test_del lead" (Phone: 09990000001)	2026-08-22 12:27:46.409
cmt774jvz0002xveku5dblbha	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:12:10.799
cmt77a8eh0005xvekksaayk13	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:16:35.849
cmt77c9so0008xvekifhhowli	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:18:10.969
cmt77eenz000bxvek72prgzrn	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:19:50.592
cmt77iumq0002xvoobkq85qj5	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:23:17.906
cmt77kdml0005xvooganxrsji	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:24:29.181
cmt77muef0002jp04i4yzl3w2	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-24 12:26:24.232
cmt77owjx0002l7044m070kus	cmt1d04o40007xvhlw271i8ag	اردلان ابوالفتحی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:28:00.333
cmt77uj2h0002xv8u3bak7trr	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:32:22.793
cmt77uoll0003xv8u39fp5a9c	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_LEAD	Deleted lead "تست دکباگ" (Phone: 09359999999)	2026-08-24 12:32:29.962
cmt77w2ie0006xv8uqxlui8sl	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:33:34.646
cmt77wnid0009xv8u03iaktvu	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 12:34:01.862
cmt77wpxs000cxv8ubnw6c74x	cmt1d04kt0002xvhli5cmdrxu	رضا کریمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-24 12:34:05.008
cmt783qp5000fxv8uuiyfj536	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:39:32.585
cmt783vyo000gxv8uxhjlsor5	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_LEAD	Deleted lead "Sina Meysami" (Phone: 09158459005)	2026-08-24 12:39:39.409
cmt7842wg000jxv8ub8s6krhp	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 12:39:48.4
cmt784b46000mxv8un52i02v6	cmt1d04kt0002xvhli5cmdrxu	رضا کریمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-24 12:39:59.047
cmt78csa10002if04l7599skg	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 12:46:34.538
cmt78de0g0002l804tcuhmay6	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 12:47:02.705
cmt78dfj40005l804iab88unr	cmt1d04kt0002xvhli5cmdrxu	رضا کریمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-24 12:47:04.673
cmt78g01y0002xvmypan9bqgr	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 12:49:04.583
cmt78g2d80003xvmy8aucojia	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	DELETE_LEAD	Deleted lead "Sina Meysami" (Phone: 09158459005)	2026-08-24 12:49:07.58
cmt78iom00002l504s57saas0	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 12:51:09.72
cmt78ipfk0003l504533rm86z	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	DELETE_LEAD	Deleted lead "Sina Meysami" (Phone: 09158176009)	2026-08-24 12:51:10.784
cmt7k9fmz0002xvinkrbckvmz	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 18:19:53.579
cmt7k9fus0005xvin9ugboc0t	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 18:19:53.86
cmt7kftfb0002kw04fhduo5li	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 18:24:51.383
cmt7kfyby0005kw04hqq58hgk	cmt1d04k90001xvhl53r6j1hq	سارا احمدی	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-08-24 18:24:57.743
cmt7khqiw0002l404qrkzg9fn	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 18:26:20.936
cmt7ki73i0001lg04bw3sz11a	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "علی سجادی" (pending-1787595312646@placeholder.local) as SALES_AGENT	2026-08-24 18:26:42.415
cmt7kijji0000i504byf6sygx	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	BULK_ACTION_LEADS	Performed bulk "delete" on 1 leads (Failed: 0)	2026-08-24 18:26:58.543
cmt7kr50d0002xv18pc6mpojw	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 18:33:39.613
cmt7li7e50002xv805b31rw6d	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 18:54:42.413
cmt7mpkjj0002xvmzphecdkir	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 19:28:25.663
cmt7mq8us0005xvmziimp6c94	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 19:28:57.172
cmt7mqpev0008xvmzj1jz3n1y	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 19:29:18.631
cmt7mx1ft0000l704mt9f61fa	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	BULK_ACTION_LEADS	Performed bulk "delete" on 1 leads (Failed: 0)	2026-08-24 19:34:14.153
cmt7obkkv0002xvarajir0ca3	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 20:13:31.76
cmt7ocz2g0002xvt8telkck33	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 20:14:37.192
cmt7oi48l0002xvhileyhiv1k	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 20:18:37.174
cmt7p95zl0002xv0uqd9mt7cj	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-24 20:39:39.153
cmt9z5qa20002xvzph50n8p9y	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 10:52:27.339
cmt9z7kq50002xvulndftq774	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 10:53:53.453
cmt9zbx290002xv9w1f91tt09	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 10:57:16.065
cmt9zojv30002kv04gsl28836	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:07:05.486
cmta15xba0002xv10m1mxsq49	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:48:35.686
cmta166190005xv10ns4rtl7v	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:48:46.99
cmta16qpp0008xv10byuo1jmo	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:49:13.79
cmta171ae000bxv10yj4ph13y	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:49:27.494
cmta17hoc000exv100e471icu	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:49:48.732
cmta17uq5000hxv10eliqo5re	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:50:05.646
cmta18fh9000kxv103rephlqy	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:50:32.541
cmta194mp000nxv1010ht3dob	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:51:05.137
cmta1diqj0002l204vznb1mh8	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-26 11:54:30.044
cmtb31pmd0002jz0416sn3xy2	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-27 05:29:04.502
cmtb32te10002jr04186ekuw3	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-27 05:29:56.041
cmtb33sp40002ju04id8jpp3e	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "موسسه آموزش عالی امین" (amininst1@gmail.com) as SALES_AGENT	2026-08-27 05:30:41.8
cmtb33v2y0005ju04raw9wxhh	cmtb33smh0001ju043916t8oi	موسسه آموزش عالی امین	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-27 05:30:44.89
cmtb33wkl0006ju04tamwonyx	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	REJECT_SIGNUP	Rejected signup request for "تست کاربر" (test@test.com)	2026-08-27 05:30:46.821
cmtb5hyg40003js0474alfcvd	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-27 06:37:41.669
cmtb5icf10001jm04r6dwp7pf	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "محمد بابایی" (pending-1787812648631@placeholder.local) as SALES_AGENT	2026-08-27 06:37:59.774
cmtb5iwj90002l204f8totpjr	cmtb5iccp0000jm041tiot8xw	محمد بابایی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-27 06:38:25.845
cmtb64ehy0005l204fx8j7t52	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-27 06:55:08.903
cmtb6bviz0009l204x13ozcrz	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-27 07:00:57.564
cmtb6c33d0001l5040humc2gz	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "سلام خممییب" (pending-1787814049766@placeholder.local) as SALES_AGENT	2026-08-27 07:01:07.369
cmtbgiejb0002l104kw79fe9n	cmt4b6xqn0000l404o53pj3z9	سینا میثمی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-27 11:45:58.295
cmtbgj8a70002l304wo0elot5	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-08-27 11:46:36.848
cmtbgld3i0003l104y3xzsi8c	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "سینا میثمی" (Role: SALES_AGENT)	2026-08-27 11:48:16.399
cmtbgliad0000i8042mgi6vl0	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "سینا میثمی" (Role: SALES_AGENT)	2026-08-27 11:48:23.125
cmtcxgnzs0002l70433a2xv06	cmtb5iccp0000jm041tiot8xw	محمد بابایی	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-08-28 12:28:16.889
cmtqxcqnx0008jl04ug91etbg	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_LEAD	Created lead "fvfvd vvdfvd" (Phone: 05424525252)	2026-09-07 07:34:00.19
cmtqxev45000cjl04hzrhdnol	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-07 07:35:39.269
cmtqxf5ay000ejl04j9dpwups	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "علی علیم" (thetruesxiiina@gmail.com) as SALES_AGENT	2026-09-07 07:35:52.474
cmtqxglkf000fjl04df82ugmm	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "علی علیم" (Role: SALES_MANAGER)	2026-09-07 07:37:00.208
cmtqxgzea0002ju040vmgfjuq	cmtqxf58p000djl04zxpavq1w	علی علیم	SALES_MANAGER	LOGIN	User logged in (SALES_MANAGER)	2026-09-07 07:37:18.131
cmtqxi60q0008l90499s16tfk	cmtqxf58p000djl04zxpavq1w	علی علیم	SALES_MANAGER	CREATE_LEAD	Created lead "ساغر رضوی " (Phone: 9154558586)	2026-09-07 07:38:13.37
cmtr19t050002l404jxcmykvy	cmtqxf58p000djl04zxpavq1w	علی علیم	SALES_MANAGER	UPDATE_LEAD_STATUS	Changed status of lead "ساغر رضوی " from CONTACTED to NEW	2026-09-07 09:23:41.718
cmty9juh90002jz04g65dzatx	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-12 10:49:50.349
cmtyj1z9c0002l004g3pia682	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-12 15:15:52.897
cmu0sav0l0003kz04ogxyjn3e	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 05:10:16.197
cmu0sbzv80000le04ulzwpco3	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "محمد عدالت" (Role: DEPT_MANAGER)	2026-09-14 05:11:09.14
cmu0sc8z70002le04twgk2f9w	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "محمد عدالت" (pending-1789362607194@placeholder.local) as SALES_AGENT	2026-09-14 05:11:20.948
cmu0sdhj00007kz04oton2ahk	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 05:12:18.685
cmu0sdwhe0001l2043ns6h33j	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "یونس دوست حصاری" (pending-1789362733634@placeholder.local) as SALES_AGENT	2026-09-14 05:12:38.067
cmu0vr8y20005le04hcdundbd	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 06:46:59.595
cmu0vui620003lc04a4vufz2c	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 06:49:31.514
cmu0vuq8e0000l504oevz3ai3	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "محمد عدالت" (Role: SALES_AGENT)	2026-09-14 06:49:41.967
cmu0vut060002l5045xhiemnr	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "محمد عدالت" (edalatmohamad40@gmail.com) as SALES_AGENT	2026-09-14 06:49:45.558
cmu0vuzke0005l504prl2afb1	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-09-14 06:49:54.063
cmu0vw5i20009l504m3kx3clt	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 06:50:48.411
cmu0vwktk000al504aypyqv3k	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "یونس دوست حصاری" (Role: SALES_AGENT)	2026-09-14 06:51:08.264
cmu0vwmfk000cl5046ttu2uq9	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	APPROVE_SIGNUP	Approved signup request for "یونس دوست حصاری" (younes.dh1381@gmail.com) as SALES_AGENT	2026-09-14 06:51:10.353
cmu0vwsw2000fl5046h8kq37y	cmu0vwmel000bl504ssx7t2ic	یونس دوست حصاری	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-09-14 06:51:18.722
cmu0vy0x2000il5041epcqyhh	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-09-14 06:52:15.783
cmu0w5enr000ele04su04vwo3	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	CREATE_LEAD	Created lead "اقای  فانی" (Phone: 09309418820)	2026-09-14 06:58:00.184
cmu0x3jkn0008lb04k3bjvev3	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	CREATE_LEAD	Created lead " رحمانی" (Phone: 09153219608)	2026-09-14 07:24:32.856
cmu0xkcdz0008l804s42n7jwc	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	CREATE_LEAD	Created lead "اقای  کوبان" (Phone: 09155236142)	2026-09-14 07:37:36.696
cmu0xvv7d0004jv045cqgqvnx	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 07:46:34.298
cmu0yxndw0002xv45gin8qnez	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 08:15:57.093
cmu0zizam0002jp04ivgpwncg	cmu0vwmel000bl504ssx7t2ic	یونس دوست حصاری	SALES_AGENT	LOGIN	User logged in (SALES_AGENT)	2026-09-14 08:32:32.302
cmu0zmew90008jp04vy71xgr9	cmu0vwmel000bl504ssx7t2ic	یونس دوست حصاری	SALES_AGENT	CREATE_LEAD	Created lead " مجتهدزاده" (Phone: 9373131768)	2026-09-14 08:35:12.49
cmu0zomoy0005xv4586n33a50	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 08:36:55.907
cmu0zoncr0008xv454bswru97	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست یادآور QA" due 2026-09-15T09:00:00.000Z	2026-09-14 08:36:56.763
cmu0zowua0009xv452vytsylg	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	COMPLETE_TASK	Completed task "تست یادآور QA" (cmu0zon400007xv45lfmtp7fq)	2026-09-14 08:37:09.058
cmu0zoxal000axv45gwg1qudk	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_TASK	Updated task "تست یادآور QA" (cmu0zon400007xv45lfmtp7fq)	2026-09-14 08:37:09.645
cmu0zoxsd000bxv45ae0jgg4l	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu0zon400007xv45lfmtp7fq)	2026-09-14 08:37:10.285
cmu0ztgk9000exv451lc92d0f	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 08:40:41.241
cmu0ztm5v000hxv45qy0lxp30	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست ثبت وظیفه از UI" due 2026-09-14T09:00:00.000Z	2026-09-14 08:40:48.499
cmu0zuve5000kxv45re3utthf	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 08:41:47.118
cmu0zwavz000nxv454rhaedlh	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 08:42:53.855
cmu0zwbgk000qxv458snxze9d	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست یادآور زنده" due 2026-09-14T08:44:53.990Z	2026-09-14 08:42:54.596
cmu0zxo4x000rxv45vnug9fen	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu0zwb75000pxv45fgjarghw)	2026-09-14 08:43:57.681
cmu10as7t0002xv26sv3vl9gg	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-14 08:54:09.497
cmu10atlz0005xv265ne2a0l0	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست" due 2026-09-14T08:30:00.000Z	2026-09-14 08:54:11.304
cmu10ax150006xv262xjf8o0c	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu10atdw0004xv26it3b7z6m)	2026-09-14 08:54:15.738
cmu10li5g0004kz04uwsg6tio	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	UPDATE_LEAD	Updated lead details for "اقای  کوبان"	2026-09-14 09:02:29.668
cmu19jnro0002gx04bj4d8hsx	cmu0vusy70001l504l8ndwg7d	محمد عدالت	SALES_AGENT	CREATE_PURCHASE_REQUEST	Created purchase request for "خرید بانک اطلاعاتی" (Amount: 2000000, Qty: 1)	2026-09-14 13:13:00.18
cmu8a0cg10002xv155bw7nb3a	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:00:21.89
cmu8a0coh0005xv1532xa1vek	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست ایجاد وظیفه" due 2026-09-14T08:15:00.000Z	2026-09-19 11:00:22.194
cmu8a0oba0002jo04rzj434nj	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:00:37.271
cmu8a0yjf0006xv15yditeoua	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a0cls0004xv15nazxujff)	2026-09-19 11:00:50.523
cmu8a2dcq0009xv15ksw4cuj3	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:01:56.379
cmu8a2zgb000cxv15tua85oqo	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:02:25.019
cmu8a36g6000fxv159cat9nt0	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست خودکار وظیفه 1789815740040" due 2026-09-19T09:00:00.000Z	2026-09-19 11:02:34.086
cmu8a39b1000gxv152etw8m6k	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a36cx000exv15tv4cjc06)	2026-09-19 11:02:37.789
cmu8a3etv0002l804alzunbvi	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:02:44.947
cmu8a3f2b0005l8043nc6bdfp	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "probe-fix-check" due 2026-09-19T08:15:00.000Z	2026-09-19 11:02:45.251
cmu8a3htq0006l804csfz01dy	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	COMPLETE_TASK	Completed task "probe-fix-check" (cmu8a3f0d0004l804bx0cwe56)	2026-09-19 11:02:48.831
cmu8a3i0p0007l8049oo20sgb	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a3f0d0004l804bx0cwe56)	2026-09-19 11:02:49.081
cmu8a3m3e000al804mx44vxqo	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:02:54.363
cmu8a3t9w0002lg04p5eu7ak8	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست خودکار وظیفه 1789815769515" due 2026-09-19T09:00:00.000Z	2026-09-19 11:03:03.669
cmu8a3vui0000l604kuol55dw	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a3t7k0001lg045dknu29n)	2026-09-19 11:03:07.003
cmu8a42c80003l604x4rij198	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:03:15.416
cmu8a42io0006l604dtpnshne	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست یادآور زنده" due 2026-09-19T11:05:15.448Z	2026-09-19 11:03:15.648
cmu8a5e140007l6046m578zzr	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a42gj0005l604s3lhvxmk)	2026-09-19 11:04:17.224
cmu8a5hiz000al60405mfhyt6	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:04:21.756
cmu8a6yfy0005lg04onoba14d	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:05:30.335
cmu8a6yl70008lg044a3j58wj	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست تقویم (تکمیل) 1789815930052" due 2026-09-19T14:05:30.360Z	2026-09-19 11:05:30.523
cmu8a6ypu000blg04b0q1aec6	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست تقویم (حذف) 1789815930052" due 2026-09-19T14:05:30.360Z	2026-09-19 11:05:30.69
cmu8a726l000elg04y8hnfgb1	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:05:35.181
cmu8a7a8a0002lb046co5spdm	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تست تقویم (فرم) 1789815930052" due 2026-09-19T09:00:00.000Z	2026-09-19 11:05:45.61
cmu8a7bth000flg044s3eoqhy	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	COMPLETE_TASK	Completed task "تست تقویم (تکمیل) 1789815930052" (cmu8a6yjl0007lg04sezz645d)	2026-09-19 11:05:47.669
cmu8a7ctq000glg047f8gg5l7	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a6yo7000alg04pa4912qe)	2026-09-19 11:05:48.975
cmu8a7e0m000bl6049rt1pri9	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a7a3i0001lb04bv57qn71)	2026-09-19 11:05:50.518
cmu8a7e8r000cl604pcp6m7fr	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu8a6yjl0007lg04sezz645d)	2026-09-19 11:05:50.811
cmu8a84xr000hxv1570luhe6l	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	DELETE_TASK	Deleted task (cmu0ztluz000gxv454zi1hckk)	2026-09-19 11:06:25.408
cmu8a95vr000fl6046lbm610m	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:07:13.288
cmu8abs6l0005lb04bh71c4w1	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	CREATE_TASK	Created task "تماس" due 2026-09-19T07:00:00.000Z	2026-09-19 11:09:15.501
cmu8b92ed000jlg04ubfwjgaq	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	LOGIN	User logged in (ADMIN)	2026-09-19 11:35:08.39
cmu8bac5f000klg04x5303qvp	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "علی سجادی" (Role: SALES_AGENT)	2026-09-19 11:36:07.684
cmu8baio9000llg049w2p4myz	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "محمد بابایی" (Role: SALES_AGENT)	2026-09-19 11:36:16.138
cmu8batmg000mlg04lkgc09vt	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "سلام خممییب" (Role: SALES_AGENT)	2026-09-19 11:36:30.328
cmu8bax690000la04h6ak03vb	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	UPDATE_USER	Updated user details for "علی علیم" (Role: SALES_MANAGER)	2026-09-19 11:36:34.929
cmu8bbn5e000nlg04q7mn6agu	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	BULK_ACTION_LEADS	Performed bulk "delete" on 6 leads (Failed: 0)	2026-09-19 11:37:08.594
cmu8bc1ny000olg04h061pkns	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	BULK_ACTION_LEADS	Performed bulk "delete" on 6 leads (Failed: 0)	2026-09-19 11:37:27.406
cmu8bccx0000plg04ep21a6eh	cmt1d04ig0000xvhlq5w8vzw5	علی محمدی	ADMIN	BULK_ACTION_LEADS	Performed bulk "delete" on 4 leads (Failed: 0)	2026-09-19 11:37:41.988
\.


--
-- Data for Name: ClassSession; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."ClassSession" (id, course_id, title, date, link, archive_url, "createdAt", "updatedAt") FROM stdin;
cmt1d05lj002nxvhly4fdr6ke	cmt1d04rx000dxvhlovppirvy	کارگاه مدیریت استراتژیک و رهبری سازمانی	2026-08-22 10:10:06.295	https://zoom.us/j/123456789	https://online.amin-inst.ac.ir/archive/strategic-mgmt.mp4	2026-08-20 10:10:06.296	2026-08-20 10:10:06.296
cmt1d05mo002pxvhl653p69tg	cmt1d04u5000gxvhls44jrlo7	حقوق ثبتی و روش‌های تنظیم قراردادهای ملکی	2026-08-24 10:10:06.336	https://zoom.us/j/987654321	https://online.amin-inst.ac.ir/archive/realestate-law.mp4	2026-08-20 10:10:06.336	2026-08-20 10:10:06.336
cmt1d05n8002rxvhl2gjn1rtz	cmt1d04ww000lxvhlgp5cjy4l	داوری در دعاوی ملکی و اسناد تجاری - جلسه اول	2026-08-19 10:10:06.356	https://zoom.us/j/111222333	https://online.amin-inst.ac.ir/archive/arbitration-law.mp4	2026-08-20 10:10:06.356	2026-08-20 10:10:06.356
\.


--
-- Data for Name: Commission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Commission" (id, referrer_id, referee_lead_id, amount, status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Course" (id, title, price, capacity, is_active, "createdAt", "updatedAt", department) FROM stdin;
cmt1d04rx000dxvhlovppirvy	دوره جامع MBA - DBA مشهد | حضوری	18500000	30	t	2026-08-20 10:10:05.23	2026-08-20 10:10:05.23	\N
cmt1d04t1000exvhlihpm892b	دوره مدیر عامل حرفه‌ای	16000000	30	t	2026-08-20 10:10:05.27	2026-08-20 10:10:05.27	\N
cmt1d04tl000fxvhlz2v8hccm	MBA DBA تخصصی مالی	15500000	30	t	2026-08-20 10:10:05.289	2026-08-20 10:10:05.289	\N
cmt1d04u5000gxvhls44jrlo7	دوره جامع آموزش مشاور املاک حرفه ای	9500000	30	t	2026-08-20 10:10:05.309	2026-08-20 10:10:05.309	\N
cmt1d04uo000hxvhlv95tolho	دوره مشاور حقوقی املاک	8000000	30	t	2026-08-20 10:10:05.329	2026-08-20 10:10:05.329	\N
cmt1d04v8000ixvhlwvu8bc3u	دوره مدیریت فروش ساختمان	11000000	30	t	2026-08-20 10:10:05.349	2026-08-20 10:10:05.349	\N
cmt1d04vs000jxvhllkx4aqpw	دوره داوری حقوقی املاک	10500000	30	t	2026-08-20 10:10:05.369	2026-08-20 10:10:05.369	\N
cmt1d04wc000kxvhl8da7qzm2	دوره تخصصی ارزیابی و قیمت گذاری املاک	12000000	30	t	2026-08-20 10:10:05.388	2026-08-20 10:10:05.388	\N
cmt1d04ww000lxvhlgp5cjy4l	دوره جامع حقوق کاربردی	14000000	30	t	2026-08-20 10:10:05.408	2026-08-20 10:10:05.408	\N
cmt1d04xg000mxvhlputwvc3f	دوره داوری حقوقی	11500000	30	t	2026-08-20 10:10:05.428	2026-08-20 10:10:05.428	\N
cmt1d04xz000nxvhl2lehnadq	دوره MBA مشاور حقوقی	13000000	30	t	2026-08-20 10:10:05.448	2026-08-20 10:10:05.448	\N
cmt1d04yj000oxvhlx798m49b	دوره مدیریت پروژه و ساخت (DPM)	22000000	30	t	2026-08-20 10:10:05.467	2026-08-20 10:10:05.467	\N
cmt1d04z2000pxvhlt3u6bk8h	دوره بازرسی فنی و کنترل کیفیت جوش	12500000	30	t	2026-08-20 10:10:05.487	2026-08-20 10:10:05.487	\N
\.


--
-- Data for Name: Enrollment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Enrollment" (id, student_id, course_id, payment_status, enrollment_date, "createdAt", "updatedAt") FROM stdin;
cmt1d05i5002dxvhlx6ebns4z	cmt1d04ly0004xvhle5yiaesa	cmt1d04rx000dxvhlovppirvy	PAID	2025-02-15 00:00:00	2026-08-20 10:10:06.173	2026-08-20 10:10:06.173
cmt1d05jb002fxvhlyb8gaxnu	cmt1d04ly0004xvhle5yiaesa	cmt1d04ww000lxvhlgp5cjy4l	INSTALLMENT	2025-02-20 00:00:00	2026-08-20 10:10:06.215	2026-08-20 10:10:06.215
cmt1d05jv002hxvhl25jzm7s8	cmt1d04n00005xvhldkytiyi0	cmt1d04u5000gxvhls44jrlo7	PAID	2025-02-10 00:00:00	2026-08-20 10:10:06.235	2026-08-20 10:10:06.235
cmt1d05kf002jxvhlh6ltihwh	cmt1d04nk0006xvhl0div8tv8	cmt1d04yj000oxvhlx798m49b	INSTALLMENT	2025-03-01 00:00:00	2026-08-20 10:10:06.256	2026-08-20 10:10:06.256
cmt1d05kz002lxvhl41j3u8lc	cmt1d04nk0006xvhl0div8tv8	cmt1d04t1000exvhlihpm892b	PAID	2025-03-05 00:00:00	2026-08-20 10:10:06.276	2026-08-20 10:10:06.276
\.


--
-- Data for Name: Interaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Interaction" (id, lead_id, agent_id, interaction_type, content, next_followup_date, "createdAt", "updatedAt") FROM stdin;
cmu0w5ejw0009le04nu5wkkmm	cmu0w5eff0007le04lt1bnbvi	cmu0vusy70001l504l8ndwg7d	SYSTEM	Lead created from source: manual	\N	2026-09-14 06:58:00.044	2026-09-14 06:58:00.044
cmu0w5ekp000ble0497p93vm3	cmu0w5eff0007le04lt1bnbvi	cmu0vusy70001l504l8ndwg7d	CALL	تماس پیگیری برنامه‌ریزی شد	1405-06-23 10:00:00	2026-09-14 06:58:00.074	2026-09-14 06:58:00.074
cmu0x3jgi0003lb04m0a1boh6	cmu0x3jcj0001lb04fjox16a0	cmu0vusy70001l504l8ndwg7d	SYSTEM	Lead created from source: manual	\N	2026-09-14 07:24:32.706	2026-09-14 07:24:32.706
cmu0x3jhc0005lb04ooxtluqt	cmu0x3jcj0001lb04fjox16a0	cmu0vusy70001l504l8ndwg7d	CALL	تماس پیگیری برنامه‌ریزی شد	1405-06-23 11:00:00	2026-09-14 07:24:32.737	2026-09-14 07:24:32.737
cmu0x5v40000alb04htlmyhf8	cmu0x3jcj0001lb04fjox16a0	cmu0vusy70001l504l8ndwg7d	NOTE	جواب نداد	1405-06-24 00:00:00	2026-09-14 07:26:21.12	2026-09-14 07:26:21.12
cmu0x86hp0001gx04961c5jxj	cmu0w5eff0007le04lt1bnbvi	cmu0vusy70001l504l8ndwg7d	CALL	12 ظهر تماس بگیرم جهت قطعیت حضور	1405-06-23 00:00:00	2026-09-14 07:28:09.181	2026-09-14 07:28:09.181
cmu0xkc9x0003l804bfstx7d3	cmu0xkc5t0001l804olemdw54	cmu0vusy70001l504l8ndwg7d	SYSTEM	Lead created from source: manual	\N	2026-09-14 07:37:36.55	2026-09-14 07:37:36.55
cmu0xkcav0005l804cdh935up	cmu0xkc5t0001l804olemdw54	cmu0vusy70001l504l8ndwg7d	CALL	تماس پیگیری برنامه‌ریزی شد	1405-06-23 10:00:00	2026-09-14 07:37:36.584	2026-09-14 07:37:36.584
cmu0xlo940001jv04lmr9fyt5	cmu0xkc5t0001l804olemdw54	cmu0vusy70001l504l8ndwg7d	CALL	دعوت به همایش  دکتر قمیان دعوتنامه ارسال شد	1405-06-23 00:00:00	2026-09-14 07:38:38.728	2026-09-14 07:38:38.728
cmu0zmes70003jp048ahzhpxp	cmu0zmeob0001jp04jnmef9i6	cmu0vwmel000bl504ssx7t2ic	SYSTEM	Lead created from source: manual	\N	2026-09-14 08:35:12.343	2026-09-14 08:35:12.343
cmu0zmet20005jp04xo8cqaw7	cmu0zmeob0001jp04jnmef9i6	cmu0vwmel000bl504ssx7t2ic	CALL	تماس پیگیری برنامه‌ریزی شد	2026-09-15 10:00:00	2026-09-14 08:35:12.374	2026-09-14 08:35:12.374
cmu10li2e0001kz04p02q6l7m	cmu0xkc5t0001l804olemdw54	cmu0vusy70001l504l8ndwg7d	CALL	تاریخ تماس و پیگیری بروزرسانی شد	1405-06-25 10:05:00	2026-09-14 09:02:29.558	2026-09-14 09:02:29.558
\.


--
-- Data for Name: Lead; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Lead" (id, phone_number, first_name, last_name, source, status, score, segment, notes, assigned_to_id, referred_by_id, target_course_id, "createdAt", "updatedAt", department) FROM stdin;
cmu0zmeob0001jp04jnmef9i6	9373131768		مجتهدزاده	manual	NEW	46	NORMAL		cmu0vwmel000bl504ssx7t2ic	\N	cmt1d04rx000dxvhlovppirvy	2026-09-14 08:35:12.203	2026-09-14 08:47:39.366	MANAGEMENT
cmu0x3jcj0001lb04fjox16a0	09153219608		رحمانی	manual	CONTACTED	64	NORMAL	معرف علیرضا قرایی ارجا از خانم یعقوبی	cmu0vusy70001l504l8ndwg7d	\N	cmt1d04tl000fxvhlz2v8hccm	2026-09-14 07:24:32.563	2026-09-14 09:00:17.171	MANAGEMENT
cmu0w5eff0007le04lt1bnbvi	09309418820	اقای 	فانی	manual	CONTACTED	74	NORMAL	معرف علیرضا قرایی ارجا از خانم یعقوبی	cmu0vusy70001l504l8ndwg7d	\N	cmt1d04tl000fxvhlz2v8hccm	2026-09-14 06:57:59.883	2026-09-14 07:28:09.709	MANAGEMENT
cmu0xkc5t0001l804olemdw54	09155236142	اقای 	کوبان	manual	CONTACTED	77	NORMAL	معرف قرایی ارجا خ یعقوبی	cmu0vusy70001l504l8ndwg7d	\N	cmt1d04tl000fxvhlz2v8hccm	2026-09-14 07:37:36.401	2026-09-14 09:02:46.539	MANAGEMENT
\.


--
-- Data for Name: PasswordResetToken; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PasswordResetToken" (id, "userId", token, "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Payment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Payment" (id, enrollment_id, amount, payment_type, status, due_date, paid_date, description, "createdAt", "updatedAt", check_number, check_bank, check_date, check_status) FROM stdin;
\.


--
-- Data for Name: PurchaseRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."PurchaseRequest" (id, requester_id, item_name, amount, quantity, description, status, "createdAt", "updatedAt") FROM stdin;
cmt1d05w50039xvhl8z0s0636	cmt1d04p80009xvhldzhqkhen	کاغذ A4 برای بخش مالی	1500000	5	نیاز فوری برای چاپ فاکتورها و مدارک مالی	PENDING	2026-08-20 10:10:06.677	2026-08-20 10:10:06.677
cmt1d05x9003bxvhl2t50rn1j	cmt1d04kt0002xvhli5cmdrxu	هدست تماس برای بخش فروش	3000000	2	هدست‌های بخش فروش خراب شده‌اند	APPROVED	2026-08-20 10:10:06.717	2026-08-20 10:10:06.717
cmu19jnnm0001gx04sfydwweq	cmu0vusy70001l504l8ndwg7d	خرید بانک اطلاعاتی	2000000	1	چاهوکی	PENDING	2026-09-14 13:13:00.034	2026-09-14 13:13:00.034
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Session" (id, "sessionToken", "userId", expires) FROM stdin;
cmt457x9a0001xvcva7c2567r	FAF9JjaQUqYSuLSYmDj3OxklsAr2HocQMAFBXNEgZw8	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 08:55:30.333
cmt45evff0001ju042pcmcp3k	mSsASu9JH_Uz_u7_dQp3Cbjboqi1I4UAgiORx-K3KgI	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 09:00:54.555
cmt45fye90001l104o7pb8lcx	oIgMoIROdGK6iFlBz5qsUUg2v9zRFkOLgRdVIJm4PNk	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 09:01:45.057
cmt4a1kyl0001l804dpqxi5vw	4XtDvRZSFjMxQ-sVRrEP-sXbaM8uNbkcX-8usfakR40	cmt1d04o40007xvhlw271i8ag	2026-09-21 11:10:32.54
cmt4a7s6g0001xvg4qxd4cagt	miErmwB76-ZwlBmLC2Ofs1mLymjxaxBAS19cmxY5Lpk	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:15:21.831
cmt4acbwu0001ld04cscuhcr7	_BzZL53FjGD2aGqWHhs4UPZxY8JBignaswqT7YIqzEM	cmt1d04qb000bxvhl72gu91dh	2026-09-21 11:18:54.029
cmt4ahjoh0001if049qo4t8x9	Up5-C3swMp0cO9oocGrp4zO2cp7tCo3bRg2V2CF9Ruk	cmt1d04o40007xvhlw271i8ag	2026-09-21 11:22:57.377
cmt4ao7690001xvecgbevfty0	Hb0GupSiR5pkK6pRCDyCz_WQARA8Jkr0Nbb5vxD8E78	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:28:07.761
cmt4aod470004xvec65r9a16l	LYJ6_yEbOrk3S-yP28WaQQphz2kBdhVluOD3dxEEBWM	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:28:15.462
cmt4awbrz0005ld04vgycc39f	yGdRvcolk2o6ZJuwsSUWPQlxGCsyUPqZczfjQ8ssLH8	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:34:26.967
cmt4b0h170001xvkz45n2mv65	H2mRuo5YUC7Y6zfHUBKQ6WbSr9y8BxR3dBjvzqaVj7g	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:37:40.411
cmt4b166i0001xvr52rko04pv	r8NdK0ZdJb-ZpTUMhtfUBb95oy0iOOQADY2yKtYORQw	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:38:13.001
cmt4b7m230009ld046yszyb4r	VfZd88-RNuzTOHYQ6uoG8-8PkP9e7Ih_r5mDsfwYHgI	cmt4b6xqn0000l404o53pj3z9	2026-09-21 11:43:13.509
cmt4b8tve000cld042x23nzo6	aD9V3h9VSWvL11DF3JUD-gLXNVegNV5ZfFH_FV-p4NA	cmt1d04o40007xvhlw271i8ag	2026-09-21 11:44:10.298
cmt4bk4xf0001xvf8e4m0qow8	SZK6tlIKSoZAMK0lekTg2a1fzIjzmO9Z5AutfpU6tgg	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 11:52:57.842
cmt4bm9b60003l404u55230lr	mclrZapN7lhyPH3LEiWS-cxPArIqfDU0ZTi-_RycpcM	cmt1d04o40007xvhlw271i8ag	2026-09-21 11:54:36.833
cmt4bnj7o0007ig04u18hjzn5	mvRfnkwOcrbtQgWgKgjv3SFKp9ZmpaR2p_nWB_WDgHk	cmt4b6xqn0000l404o53pj3z9	2026-09-21 11:55:36.323
cmt4bvhrm0001xv8gl2wcz55a	wF9Vt4MFUfuB9piaFpjpr0zSmjqMKFhM54EiRwOcw10	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 12:01:47.698
cmt4c5i5p0001xvx865agu1kp	0_bAHc7TZ2cLIiT7JXaVl8x22Ix0bmd_2fqxNVWl5Bs	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 12:09:34.764
cmt4c99g50001l804qjz8riu7	pFp2T_tnCrW3Sp5ZETirYKX6-c1CRQLeLmykK857QQA	cmt4b6xqn0000l404o53pj3z9	2026-09-21 12:12:30.101
cmt4c9xk90004l80400ueoc87	dZDIlKWISF3BemBNb4GzLZ_GeRKuZW-L7rEp8OMoK3w	cmt1d04o40007xvhlw271i8ag	2026-09-21 12:13:01.352
cmt4cmbtl0006l404tcv8dbn4	YaNiLGD7vpYquPbvrH3wExzFvXLhMUd9SyDy7f92p7U	cmt4b6xqn0000l404o53pj3z9	2026-09-21 12:22:39.705
cmt4cqu990001xvnzgs893g53	RwfK9S-zHMA7QLI0H83h9ZRk1HOZ-dMgFrnt6_zTncg	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 12:26:10.221
cmt4crlsf0004xvnzt23t8hu7	a0_EPSJJCsGRHLDjJ2_nV3ixynO2hS4iVWGPNt8TUX4	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 12:26:45.903
cmt4cstvc0007xvnzccqa1i2j	K5t1mC1TGjBXcwIt2hEZ6HH8_pVJNg3B8Qxi57HK0T0	cmt1d04ig0000xvhlq5w8vzw5	2026-09-21 12:27:43.031
cmt774jnx0001xvekzhyg4ikn	D_tV54upovSqHunyeCy-QIyyLeSoMGSAKYdx6JE5AJ0	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:12:10.508
cmt77a86p0004xvekbtb33bp4	3Z1ZDXCKZX56W2Sk4uV-Cd-vQDJ9VXqM3OjwLNvLs9w	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:16:35.568
cmt77c9l10007xvekwg7szbnx	I-nYkASOvJzkk7UFNY3JPao5yKvC-C5HKzVhprc2228	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:18:10.692
cmt77eegc000axvek8u62n0wi	dGZ1MW52wZ6jvcCwNmot3VhPzxvah17nr31BFdaQ8wY	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:19:50.315
cmt77iuf00001xvoosmdzrpjy	T2b4WCrfP_ASHl0udF2ePhXF_yAE36BP2lxmYS2FcU8	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:23:17.627
cmt77kdew0004xvoofz1gq0a8	-Awi_So40UUZD6c8UYElqGwSez0bXeGsjtpvdI5RdrQ	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:24:28.903
cmt77mucn0001jp04a5xvzym0	Fkn6HOpmSRedSmZ8zFCDfcfyzXG8kbklrRS0ONq_AYc	cmt4b6xqn0000l404o53pj3z9	2026-09-23 12:26:24.166
cmt77owin0001l7041biablit	qgMsNNI_dsFSalghQGa2mqrBJxi7YHApnpcHUIWzVI4	cmt1d04o40007xvhlw271i8ag	2026-09-23 12:28:00.286
cmt77uisj0001xv8udbftab3p	rSJNg-KPO37idFXzY2CRzQ8OTeJ0vo8UhEqZ8LX3uhg	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:32:22.435
cmt77w2ei0005xv8u6dpwlc59	2VB7tQbXo1ijDydemXL3DBq-VN_X5QDTDQhPaXDia40	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:33:34.506
cmt77wnei0008xv8ub45cgm0z	cVs0oK-wxJW2-tVImL_EBoVopZWt_uQz_eahtmYlwvM	cmt1d04k90001xvhl53r6j1hq	2026-09-23 12:34:01.721
cmt77wptv000bxv8u9g9e66qn	kNIZL8DU3Uo6PFN7MkZVswGfPx66OiPbIbwdwXIPM7Y	cmt1d04kt0002xvhli5cmdrxu	2026-09-23 12:34:04.866
cmt783qhb000exv8uat01poba	LxdZYP8cvLiQV4j8Ca-oR0AoY6hHI419BxZmpK4Zf0U	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:39:32.302
cmt7842sj000ixv8uta0edubx	4omyVAYZ61Psbat2ay49P8sxFuDUHWOmUdGksTdSaGQ	cmt1d04k90001xvhl53r6j1hq	2026-09-23 12:39:48.257
cmt784awh000lxv8uibzskqpz	8Ig32V00pWPOxMasePJchlJiCD0a-favrl00B6geM3U	cmt1d04kt0002xvhli5cmdrxu	2026-09-23 12:39:58.769
cmt78cs8e0001if04xs2ccd2q	7hazXLvZFTztVcLM4oHE48YHwGMllI7ysHa1N5UvnEY	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 12:46:34.477
cmt78ddyo0001l804977htmzh	4JJwL6fLH-3fpjPcpslcGDmflrPSZ1Txg8QNiyCTfWo	cmt1d04k90001xvhl53r6j1hq	2026-09-23 12:47:02.64
cmt78dfh90004l804z9q6ev2k	LplU2bcQGPegbrZir9E8E35Z_MAD1CjnTOOMgtje5Mw	cmt1d04kt0002xvhli5cmdrxu	2026-09-23 12:47:04.604
cmt78fzu60001xvmyzrk3lznq	1M6XO7FBDq7dAjrQ4PHZcfMSUdRc1VS0_mpQJTXDad4	cmt1d04k90001xvhl53r6j1hq	2026-09-23 12:49:04.301
cmt78iok10001l5041apobni0	EXSUVYjSw9YKLj-A4Qy8YNc8G5pjdKewxb_6gbhwIdA	cmt1d04k90001xvhl53r6j1hq	2026-09-23 12:51:09.648
cmt7k9fkj0001xvinmfu0rngh	NcncZxyADC_wcXg9hpx5bPwtpEVMJqm2iZVc_Aho4_A	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 18:19:53.49
cmt7k9ftl0004xvinuzgnwc1o	JBjcPZJLPRCR9EKivKL0PsXC2oXQU9uUGeBKL2oRvnw	cmt1d04k90001xvhl53r6j1hq	2026-09-23 18:19:53.816
cmt7kftdn0001kw04bf90xbcb	MWddNh1NBEsoL4VTLrsalfNUYL11SGIu-Y3JgtzGngg	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 18:24:51.322
cmt7kfyb30004kw04brn3rz7d	K9Nn1whyLWdoU64NMArKa-o8sLXNLx528DdlyFicvAA	cmt1d04k90001xvhl53r6j1hq	2026-09-23 18:24:57.71
cmt7khqha0001l4047y27cpl0	QnV5q9rfHfMFbmaEcJqrd6uKcxezeb8VbmMk7xQplRw	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 18:26:20.877
cmt7kr4y00001xv18cuc7v7wf	wdYSDGy5k7Ryp2DshmrwVxPCLaP7AxVKEinvKPeA0dI	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 18:33:39.527
cmt7li7br0001xv80fwpozxe9	63nr1sUpgJEo5ED59m0OLZFN2M5Ht2vg58tNVnioBvs	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 18:54:42.327
cmt7mpkh50001xvmzz1vpfddc	9XHmaGurHvOWLpENJdE-Tu9DNZ2tghOYLeEKA0K_n1o	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 19:28:25.576
cmt7mq8sm0004xvmzm9m4i21v	xWI4NhtlvOVnc4BmY7lN0vSztcDC8Okj8oVEEULyjcE	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 19:28:57.093
cmt7mqpcm0007xvmzd00abex3	sLHl60tPgcUBekaV-jUZh1V0-0F2AQRO0pt0FPG4N-g	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 19:29:18.549
cmt7obkic0001xvarb6d1b3jw	8biPoXM6esX3pr8rODHCsP-VqoACE220jgj_QeKPBOA	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 20:13:31.668
cmt7ocz0f0001xvt81td1uwce	u5YqKeRjge659H-kMhuzA-mT6vBx9agdkJHe79nabJ8	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 20:14:37.119
cmt7oi46g0001xvhirre05y61	kn_qTlk8ktslQhlbLz3p4K8Fj2hNthrlQHwHYOtrvIo	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 20:18:37.095
cmt7p95wv0001xv0udlf9d8oe	OA7Za75b9F0caKOgckSRAZN7oO6qOJ4LZffVa6Q30pI	cmt1d04ig0000xvhlq5w8vzw5	2026-09-23 20:39:39.055
cmt9z5q210001xvzpc7te70rp	Q8X0FqqlhE9oZh_QdxR_B4iJZ6fo3DW7EZLWC4dLCx0	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 10:52:27.048
cmt9z7kih0001xvulwbvlc1ad	rZ_4_gCFTev9y5CaCmOERZV5Hy56G-WsgBrZYxUHH0Y	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 10:53:53.177
cmt9zbwun0001xv9wk4u7x4uv	jVUN-XxJ9JtbJFLetKHyS8vRkyJsVEQfoj_LGawdrGQ	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 10:57:15.79
cmt9zojsz0001kv047seeoz4r	wSuQq9pStgARbcOV15H9XwVyddRFW-OHl1aW9Qko948	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:07:05.409
cmta15x3j0001xv10c94czuv6	4w8olNugvWqoMCWwkAxrUIc-o_kyGcgrDiwDYTzKIvg	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:48:35.407
cmta165xh0004xv10jwx0t7bj	QTeXqrRHf4ZcGp8vQ_Ube1o8Da1D-zVp7OjPrIHH07c	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:48:46.853
cmta16qhy0007xv1007g5rvix	lNmjs9u95nd-l7KyGNvRZvOkTa8o1XU2oo2vC8vWSq4	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:49:13.509
cmta1716h000axv1096rqcr93	Z7wLuNiU09mNh_2sX-L0O5JGlJmL-ONIyf_Z04b3BFY	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:49:27.353
cmta17he1000dxv10db7kgq6i	RYNji3N0XxKHW9ajnqMA8mYe2ypPlzSHoevoemF8MMo	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:49:48.361
cmta17uis000gxv10b6ff53u6	shoaMYOtZ01J0wcxGPRthN3aY6Jqev4FvjSRNqW_dO8	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:50:05.379
cmta18fde000jxv1090zxviuk	m9P7rvo2OBNU1ZuGa17sV1tM4jON21PtePp0l9zLISo	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:50:32.401
cmta194f7000mxv10dfxbz6yt	bHI2gEXm9ur8dSG8FP16Rc2q8boHVB-imNe3Epv0WbI	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:51:04.866
cmta1dip00001l2045bbrr0ro	H7jyzbMXg7yW9QxVgpZ6CpAcv6ERO76ej1er-RKBCKM	cmt1d04ig0000xvhlq5w8vzw5	2026-09-25 11:54:29.987
cmtb31pkl0001jz04etz2pjvs	yFZYdqPwqDys035kTQ_xoHOrRM1ENFdL3GtTwJihZNQ	cmt4b6xqn0000l404o53pj3z9	2026-09-26 05:29:04.436
cmtb32tcf0001jr042qkwmjvn	EUkr2TlAH8M8F5rRCdPpLQjcHkFFmW2VMZ8JAtSraKg	cmt1d04ig0000xvhlq5w8vzw5	2026-09-26 05:29:55.982
cmtb33v1p0004ju04wr8tivre	nXG2bfC5LyPzW7xP91Fk_2-5ZMZcridtcynaZwvXfYY	cmtb33smh0001ju043916t8oi	2026-09-26 05:30:44.844
cmtb5hye60002js04ih0usjo3	rjyt5VbtP-Tt7SmCm8Q6b6OBUK8RuUCPy0H927UlVvs	cmt1d04ig0000xvhlq5w8vzw5	2026-09-26 06:37:41.597
cmtb5iwhd0001l2041629z0vu	Uf2V3BGOywSUbMp-3Pvj144to3K8H9XivdWANvK3v0I	cmtb5iccp0000jm041tiot8xw	2026-09-26 06:38:25.776
cmtb64efi0004l204zyp056ix	TnGHQNkeSk0YVOLoe1up-A7sSSd1ieSx52rxsPkyFcc	cmt1d04ig0000xvhlq5w8vzw5	2026-09-26 06:55:08.814
cmtb6bvhd0008l2049zib4mb9	tOzkjXqJh5Tc2SH2JYrD59whh-G1UsIr0cy1jeqL0yk	cmt1d04ig0000xvhlq5w8vzw5	2026-09-26 07:00:57.504
cmtbgiehi0001l104bc33hymc	ahAq_N9Ul0cYeGsUnURM12KgPoP7M_ECjDoNCz_o-1U	cmt4b6xqn0000l404o53pj3z9	2026-09-26 11:45:58.23
cmtbgj88v0001l3046b6cqgd7	eRXLPvGDHUmWhsbNv_VEvCGie9LtVikEWFq2Y-KZYYQ	cmt1d04ig0000xvhlq5w8vzw5	2026-09-26 11:46:36.798
cmtcxgnwo0001l704edjwkxy3	_t4KxSA88dPn8tkevidMq5vhPS-oFPRcwmtw6RwlM_4	cmtb5iccp0000jm041tiot8xw	2026-09-27 12:28:16.776
cmtqxev2q000bjl04rk1we75o	i1Bh-qwmC5ejMaJL32nQhweFkRzEkrdYE8qElQL_hxw	cmt1d04ig0000xvhlq5w8vzw5	2026-10-07 07:35:39.218
cmtqxgzcs0001ju049igzhw0j	RxYoah42hEtBKEYGwLDiW7NbwPW7MQxgnOOfzwo3x4I	cmtqxf58p000djl04zxpavq1w	2026-10-07 07:37:18.075
cmty9jufb0001jz04b8l0kdoc	9_2aUUe9dcHGUZ0oTO8qegpUP8Nh9F5G56oDb-annzE	cmt1d04ig0000xvhlq5w8vzw5	2026-10-12 10:49:50.278
cmtyj1z7j0001l0045ttyp3fc	XgAbyJ1N0b7ruxdlsT9buVVhqulhe8C1tnIIfOFz44w	cmt1d04ig0000xvhlq5w8vzw5	2026-10-12 15:15:52.83
cmu0sauym0002kz040ke71rkc	lQTAB2cvEAUbfnJgK3mR3gJsXKiRL6BQ8dMyDE7rugM	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 05:10:16.125
cmu0sdhhg0006kz04c9ca0c87	GkH8FWb_xHAQXCuowm1UYzVwehDkiZEuu71OmPVVG7s	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 05:12:18.627
cmu0vr8wc0004le0422umda5o	t5TPiu2OdFzNaS04Bd4aBJjqwLlTZb_FXVYGMLCsZ7Y	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 06:46:59.531
cmu0vui0u0002lc04xhh3ez1h	wW6vES2_REWVIywbxNjjFo2dJrAyInTyvAA9qSQOug8	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 06:49:31.325
cmu0vuzjh0004l504lmrqm3d4	Zd3ouriH3nqg2fW5xeFU-5K4B5zANKqh2okg1cYeycI	cmu0vusy70001l504l8ndwg7d	2026-10-14 06:49:54.028
cmu0vw5gt0008l50430nm55o1	NS7oTiga1Hw9WUK6SOSxkzZ8sCMOLmXv-utwuFswFEo	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 06:50:48.364
cmu0vwsve000el504rurooghy	MLdOgi8lWmPVQI18AxzlypDUwfu5bVqcCDzNIBVxuNI	cmu0vwmel000bl504ssx7t2ic	2026-10-14 06:51:18.698
cmu0vy0vm000hl5040u41128y	azf4zKaEnNVKdxCZ4rnHU4yUUPgQT558peRp8d1QY6s	cmu0vusy70001l504l8ndwg7d	2026-10-14 06:52:15.73
cmu0xvv5z0003jv049alsgg5q	Wb9j2kFQmDc-8WLZQx3HA2Hm9JWIcBegwxWHFiYJixo	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 07:46:34.247
cmu0yxn3w0001xv45qykedqwn	IEXMsxAKeWsI7riz-nswfQIWCM3ScJkfuudvF_Y424s	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 08:15:56.732
cmu0ziz8n0001jp045ikbcbiv	Zzr2zfpbkFzWeJPVKLo5DCjU-CAXFK3HML6mloX6BzU	cmu0vwmel000bl504ssx7t2ic	2026-10-14 08:32:32.231
cmu0zomhy0004xv45kzj83rig	E8aNAnBTkJlRw_IZ8mmQ55KkTfNfm-vm4ao7MgYR0p4	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 08:36:55.654
cmu0ztggq000dxv45qmt4ogj1	IXlgX5yVuDE13C1Zo551DfrDp_104hjYaURJfJMA650	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 08:40:41.113
cmu0zuv6v000jxv455gri2puq	oVwC6EWPSag3oeYVSBhoKSaiO7JP2hFd5md6Th3JS8U	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 08:41:46.855
cmu0zwaop000mxv45ra11phod	0bhaEmH6_asU3NBZCf9otCJM8XPDYgLg21F68i3UYCs	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 08:42:53.592
cmu10as1a0001xv26hubfs5y5	Im6Uuqa69cIANxb9Ajm6oDD-7y97yB1bxvzeWze8VTA	cmt1d04ig0000xvhlq5w8vzw5	2026-10-14 08:54:09.261
cmu8a0cdr0001xv155wte1t23	SlO3iCyfF75Segnz_UP67miBFZnTZ3lv_HWLYQTILBs	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:00:21.806
cmu8a0o9y0001jo04vdd9rjz8	fvesrwQ3A7JY4ogYGsH9YjUdFJGf-Mft2dgFYBvCP_Q	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:00:37.222
cmu8a2dbr0008xv158mv8ymau	zFGcH1NfgmPdHK4pJV-WKEawjfTMv1HY4CkJQbH1PYs	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:01:56.342
cmu8a2ze7000bxv15azl6wfok	J4neXdtsX8YYJec31sERtJL_WJoTpRWvaDkLNS8S57A	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:02:24.942
cmu8a3enm0001l804o324o6al	yFJSoYroCSet5BfJOlCBGeVx6htzY8LBEveDSaTtWSM	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:02:44.721
cmu8a3m2l0009l8048o8k46yi	ULurqjbC66zu8ZLvvHdn2Dz0-GafyrOTD9F15_WYQ6Q	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:02:54.333
cmu8a42av0002l6048zcos9no	eiMFdOszC-m_p1aK7H_AKL7pEk4ssmFtCQfnFp85p2g	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:03:15.367
cmu8a5hhn0009l604fy2cx0r9	GyOvY0JX82ABzYccctOcTwETm0Dl5OpCcKnfEyqnYz4	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:04:21.707
cmu8a6yep0004lg04npmpdt8a	VbRHqEER1uUU-p1cZWp_4JroJVOv86kHx_61hFBunt0	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:05:30.288
cmu8a725r000dlg044wxvqrnl	AU380pn_-1gkRyWbje07fWWHyhBx3HE3DvHpT27Xeuc	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:05:35.15
cmu8a95ug000el6043617oiwl	EgjsMQVM3W0MlZgBjjvCmMrtribsDCIlh22FsAewzl0	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:07:13.232
cmu8b92cq000ilg04vqv8spwq	P1Vd57tkUCc1JDzP7pPvY_lcx_2vYI-wXZvieG9nMAc	cmt1d04ig0000xvhlq5w8vzw5	2026-10-19 11:35:08.329
\.


--
-- Data for Name: SignupRequest; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SignupRequest" (id, email, first_name, last_name, phone_number, desired_department, "passwordHash", status, reviewed_by_id, reviewed_at, review_note, "createdAt", "updatedAt") FROM stdin;
cmt4aonxk0006xveck26dzovl	test@example.com	تست	کاربر	pending-1787398109479	\N	scrypt$16384$8$1$12OVV2lUfxv17YoP4XDmQw==$IwdS2ZNrxDL2hqZSzTtZWzJRBTw+DmLNB87bBp4rstK3yvHaiTEDfuItliSthf0+SbJcma4hnaR88uE/KieZZw==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-22 11:38:15.253	\N	2026-08-22 11:28:29.481	2026-08-22 11:38:15.254
cmt4avlsf0003ld0440vl03ca	sinameysami8@gmail.com	سینا	میثمی	09158176009	LAW	scrypt$16384$8$1$eWWcq55XHj3GJNCmkC7yDg==$jsPbsnBoptXLWYdWwooV3xTZ+FTlpjzC3N3SjDpFD4CVZFyT03L3016KgY1YoLbxJwqVmGqG4CrXjOBly8jf8g==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-22 11:42:42.028	\N	2026-08-22 11:33:53.296	2026-08-22 11:42:42.029
cmt4aox9w0007xvecbte49bbz	pending-1787398121588@placeholder.local	تست2	کاربر2	09991234567	\N	scrypt$16384$8$1$vYhRHMxrnRVCg5Nn3wZbvQ==$58jm1qJ7tJMVXg3z+FKHXm/fVaSCYXB+MZNEVK5uHXwAin2XpozreAiXIZl/cpgfc6F2RaK2WS9QjA57DI1WIg==	REJECTED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-22 11:42:50.259	\N	2026-08-22 11:28:41.589	2026-08-22 11:42:50.26
cmt7k3evb0000l904cwsxafjn	pending-1787595312646@placeholder.local	علی	سجادی	09155176009	\N	scrypt$16384$8$1$MKAU7Ix1OVLG8M24W7+yww==$jLEYf3dgDQ9/qb2dpwRDMmnF6bOdv2NSPTHVmTmAjVeNWiHiuoIm6wbLJXfEV/lfcfWXu3/2JecyBL7sqDi1nw==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-24 18:26:42.35	\N	2026-08-24 18:15:12.647	2026-08-24 18:26:42.351
cmtb339hh0000ju04cn48pl0q	amininst1@gmail.com	موسسه آموزش عالی	امین	09150066349	\N	scrypt$16384$8$1$CMjcyzTRIdCKOJ5dVBzzXA==$eGEM3nulbur0L/2oqDh/pnezzglvGansgxcFysxfbLdsqIgcqLM9LNd+N+gyfTWyjEbnbrBpin6UUKfyXqDZww==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-27 05:30:41.738	\N	2026-08-27 05:30:16.901	2026-08-27 05:30:41.739
cmt4bwce90003xv8gkk4fblho	test@test.com	تست	کاربر	pending-1787400147392	\N	scrypt$16384$8$1$MBX+FjR83hrQrbt0Hkux/w==$z7KzWQiNg989xV7JR8pUG8tvJg7CY9cvhtmH+m2LAffyczr13284JY3zEyfZ7ma25PgrZWTh33hWVmBM3FlZPg==	REJECTED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-27 05:30:46.759	\N	2026-08-22 12:02:27.393	2026-08-27 05:30:46.76
cmtb5hoe00000js04iv7k2e1f	pending-1787812648631@placeholder.local	محمد	بابایی	09158154545	\N	scrypt$16384$8$1$uzNuoS8BvEF6sTqHdFNzZg==$ZjLSb2NyTTMgBpmDT1z6DaImvqC5vYgY3/not2HnwwCyQ2aMh2hxkeIcNefZAgkeHbFNbx3zKRqADRGV0ew63g==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-27 06:37:59.718	\N	2026-08-27 06:37:28.632	2026-08-27 06:37:59.719
cmtb6bpie0006l204mfu88dfk	pending-1787814049766@placeholder.local	سلام	خممییب	09158888888	\N	scrypt$16384$8$1$I/G/BjoMuSUk59+EsORjbQ==$D1DwB7nqWx0EuYF/4aXBiTxfVwzvxKyk8AhGTVfSpykxywzBlS0rtXSfskKzEJ5s6RKQU6F4YFL4hYO5X7S/hQ==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-08-27 07:01:07.304	\N	2026-08-27 07:00:49.767	2026-08-27 07:01:07.305
cmtqxep140009jl04dnld0flz	thetruesxiiina@gmail.com	علی	علیم	09158885445	\N	scrypt$16384$8$1$PiJVsGZ6nlFbbeCgXXVbEA==$EXOusTOfGLV4f/B35UI1CvGFqeiSzigbeXIDzlFhJUFft52DKvzYu/x+v0vwohNo3qya5z1tkGtk73OYp606ww==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-09-07 07:35:52.426	\N	2026-09-07 07:35:31.384	2026-09-07 07:35:52.427
cmu0sao2j0000kz04hfzb5n8u	pending-1789362607194@placeholder.local	محمد	عدالت	۰۹۳۰۸۸۳۴۹۲۹	\N	scrypt$16384$8$1$kmhTN8i+ocTNnH14FYmtHA==$TQ998f28nfoY8g3KkcqgZ1/Vjk8Yv7xCL3kNUSzvCpDGmnuwC/0pU9JbXo6K9yDKWKVHR0xxMqrKfXb0p7A2Ag==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-09-14 05:11:20.89	\N	2026-09-14 05:10:07.196	2026-09-14 05:11:20.89
cmu0sddmq0004kz043n9si68i	pending-1789362733634@placeholder.local	یونس	دوست حصاری	۰۹۳۳۸۶۶۸۷۰۴	\N	scrypt$16384$8$1$o7tqTtdmU2WmWAgh3ZlZfQ==$gnk3+AsZCZVITmpdPYA8desrOa4O72170fhCScSgdHuOxSJXye60NhAoyVaOOGBtEHGsw1DmtdreuUINtAFcJw==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-09-14 05:12:38.003	\N	2026-09-14 05:12:13.635	2026-09-14 05:12:38.004
cmu0vubg40000lc04wjm982h3	edalatmohamad40@gmail.com	محمد	عدالت	09308834929	\N	scrypt$16384$8$1$k92jsuaJ7ur97oq8vy0srw==$HlefZqJ0D36TZfEggewvVVh0/92TJtNNXuVInk4kl1rNkmJyt3YJ/Bezt56prMCtuUWANXIY9QhLTLUjgc9iSw==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-09-14 06:49:45.513	\N	2026-09-14 06:49:22.804	2026-09-14 06:49:45.514
cmu0vvzn60006l504lx16ogiq	younes.dh1381@gmail.com	یونس	دوست حصاری	09338668704	\N	scrypt$16384$8$1$fzn4s+Ap7ZWRiZpS2EFaLQ==$Y+Rk3BP8MaVkMOmTmTf//pjhyq2mZclE2P2MFth6jbqZOnAoa1c/ffybXRpIFbFDJU0HOoHO6Z/4YKTM997omQ==	APPROVED	cmt1d04ig0000xvhlq5w8vzw5	2026-09-14 06:51:10.328	\N	2026-09-14 06:50:40.819	2026-09-14 06:51:10.329
\.


--
-- Data for Name: Task; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Task" (id, agent_id, lead_id, title, description, due_date, status, "createdAt", "updatedAt", reminder_time, reminder_sent) FROM stdin;
cmt4csuti000gxvnz6lvgpn3s	cmt1d04ig0000xvhlq5w8vzw5	\N	تماس پیگیری با لید: test_del lead		2026-09-01 10:00:00	PENDING	2026-08-22 12:27:44.262	2026-08-22 12:27:44.262	15	f
cmt4bzlie000exv8glmhjsyoe	cmt1d04ig0000xvhlq5w8vzw5	\N	تماس پیگیری با لید: تست دکباگ		2026-09-01 10:00:00	PENDING	2026-08-22 12:04:59.175	2026-08-22 12:04:59.175	15	f
cmt4bomk8000gl104qj731gsm	cmt4b6xqn0000l404o53pj3z9	\N	تماس پیگیری با لید: Sina Meysami		4222-02-02 14:22:00	PENDING	2026-08-22 11:56:27.321	2026-08-22 11:56:27.321	15	f
cmt4bom4s0007l1040x1y8y5e	cmt4b6xqn0000l404o53pj3z9	\N	تماس پیگیری با لید: Sina Meysami		4222-02-02 14:22:00	PENDING	2026-08-22 11:56:26.764	2026-08-22 11:56:26.764	15	f
cmu0x3ji50007lb04ozs92gt2	cmu0vusy70001l504l8ndwg7d	cmu0x3jcj0001lb04fjox16a0	تماس پیگیری با لید:  رحمانی		1405-06-23 11:00:00	PENDING	2026-09-14 07:24:32.765	2026-09-14 07:24:32.765	15	f
cmu0zmett0007jp04lvrgzohy	cmu0vwmel000bl504ssx7t2ic	cmu0zmeob0001jp04jnmef9i6	تماس پیگیری با لید:  مجتهدزاده		2026-09-15 10:00:00	PENDING	2026-09-14 08:35:12.402	2026-09-14 08:35:12.402	15	f
cmtqxcql60007jl04juc6wv7l	cmt1d04ld0003xvhleh4idegh	\N	تماس پیگیری با لید: fvfvd vvdfvd		2026-09-08 10:00:00	PENDING	2026-09-07 07:34:00.09	2026-09-07 07:34:00.09	15	f
cmtqxi5yk0007l9044ne2gzr0	cmt7ki70t0000lg04corpsid8	\N	تماس پیگیری با لید: ساغر رضوی 		2026-09-08 10:00:00	PENDING	2026-09-07 07:38:13.292	2026-09-07 07:38:13.292	15	f
cmu10li360003kz044h4pklij	cmu0vusy70001l504l8ndwg7d	cmu0xkc5t0001l804olemdw54	تماس پیگیری با لید: اقای  کوبان		1405-06-25 10:05:00	PENDING	2026-09-14 09:02:29.586	2026-09-14 09:02:29.586	15	f
cmu8abs4g0004lb04brjsgqec	cmt1d04ig0000xvhlq5w8vzw5	\N	تماس	تماس مجدد	2026-09-19 07:00:00	PENDING	2026-09-19 11:09:15.424	2026-09-19 11:09:15.424	60	f
cmu0w5elh000dle04ezayhimv	cmu0vusy70001l504l8ndwg7d	cmu0w5eff0007le04lt1bnbvi	تماس پیگیری با لید: اقای  فانی		1405-06-23 10:00:00	PENDING	2026-09-14 06:58:00.101	2026-09-14 13:10:34.774	15	f
cmt1d05rq0033xvhlmgnu0j35	cmt1d04ld0003xvhleh4idegh	\N	بررسی درخواست تخفیف الهام رحیمی با مدیر فروش	لید درخواست تخفیف ۱۰ درصدی برای پرداخت نقدی کامل دارد.	2026-08-20 10:10:06.518	PENDING	2026-08-20 10:10:06.519	2026-08-20 10:10:06.519	\N	f
cmt1d05r60031xvhlncpv2pz7	cmt1d04kt0002xvhli5cmdrxu	\N	ارسال سرفصل‌های دوره حقوق کاربردی به نازنین قاسمی	سرفصل‌ها به آدرس ایمیل ثبت شده ارسال شود و پیام تایید داده شود.	2026-08-19 22:10:06.498	COMPLETED	2026-08-20 10:10:06.499	2026-08-20 10:10:06.499	\N	f
cmt1d05q1002zxvhl57qjsa4t	cmt1d04kt0002xvhli5cmdrxu	\N	تماس پیگیری با فاطمه موسوی برای ثبت‌نام نهایی دوره MBA	مشتری در مکالمه قبلی ابراز علاقه شدید کرده و خواستار اطلاعات پرداخت قسطی بود.	2026-08-20 14:10:06.457	PENDING	2026-08-20 10:10:06.457	2026-08-20 10:10:06.457	\N	f
\.


--
-- Data for Name: Teacher; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Teacher" (id, name, phone_number, email, specialty, status, "createdAt", "updatedAt") FROM stdin;
cmt1d05uh0036xvhliro0fa1z	استاد احمدی	09127777777	ahmadi@example.com	مدیریت و MBA	ACTIVE	2026-08-20 10:10:06.617	2026-08-20 10:10:06.617
cmt1d05vl0037xvhlodqr0byk	استاد رضایی	09128888888	rezaei@example.com	حقوق و داوری	ACTIVE	2026-08-20 10:10:06.657	2026-08-20 10:10:06.657
\.


--
-- Data for Name: Ticket; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."Ticket" (id, student_id, title, description, status, priority, "createdAt", "updatedAt") FROM stdin;
cmt1d05ns002txvhlj0r6ih06	cmt1d04ly0004xvhle5yiaesa	درخواست تمدید پرداخت قسط دوم دوره حقوق کاربردی	با سلام، بنده به علت تاخیر در دریافت حقوق ماهانه درخواست تمدید پرداخت قسط دوم را تا انتهای ماه جاری دارم. با تشکر.	PENDING	HIGH	2026-08-20 10:10:06.376	2026-08-20 10:10:06.376
cmt1d05ox002vxvhlcb6q1evk	cmt1d04n00005xvhldkytiyi0	مشکل در ورود به لینک کلاس آنلاین MBA	سلام، در جلسه قبلی خطای احراز هویت در نرم افزار زوم دریافت کردم و نتوانستم وارد کلاس آنلاین شوم. لطفا راهنمایی کنید.	RESOLVED	NORMAL	2026-08-20 10:10:06.418	2026-08-20 10:10:06.418
cmt1d05ph002xxvhlygjvq2pq	cmt1d04nk0006xvhl0div8tv8	درخواست صدور گواهی دوره داوری املاک	با سلام، با توجه به اتمام دوره داوری املاک در هفته گذشته، درخواست صدور گواهینامه فیزیکی پایان دوره را دارم. سپاس.	IN_PROGRESS	LOW	2026-08-20 10:10:06.438	2026-08-20 10:10:06.438
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."User" (id, first_name, last_name, phone_number, role, is_active, referral_code, wallet_balance, "createdAt", "updatedAt", department, personal_notes, admin_notes, email, "passwordHash", scope, "isApproved") FROM stdin;
system	سیستم	خودکار	00000000000	ADMIN	f	\N	0	2026-08-20 10:10:04.934	2026-08-20 10:10:04.934	\N			\N	\N	STANDARD	f
cmt1d04ly0004xvhle5yiaesa	امیر	نوری	09121234571	STUDENT	t	AMIN-AMIR123	750000	2026-08-20 10:10:05.014	2026-08-20 10:10:05.014	\N			\N	\N	STANDARD	f
cmt1d04n00005xvhldkytiyi0	زهرا	رضایی	09121234572	STUDENT	t	AMIN-ZAHRA456	0	2026-08-20 10:10:05.052	2026-08-20 10:10:05.052	\N			\N	\N	STANDARD	f
cmt1d04nk0006xvhl0div8tv8	محمد	صادقی	09121234573	STUDENT	f	AMIN-MOHAMMAD789	0	2026-08-20 10:10:05.073	2026-08-20 10:10:05.073	\N			\N	\N	STANDARD	f
cmt1d04k90001xvhl53r6j1hq	سارا	احمدی	09121234568	SALES_MANAGER	t	\N	0	2026-08-20 10:10:04.954	2026-08-20 10:11:21.363	\N			09121234568@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04kt0002xvhli5cmdrxu	رضا	کریمی	09121234569	SALES_AGENT	t	\N	0	2026-08-20 10:10:04.974	2026-08-20 10:11:21.421	\N			09121234569@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04ld0003xvhleh4idegh	مریم	حسینی	09121234570	SALES_AGENT	t	\N	0	2026-08-20 10:10:04.994	2026-08-20 10:11:21.46	\N			09121234570@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04o40007xvhlw271i8ag	اردلان	ابوالفتحی	09120000001	ADMIN	t	\N	0	2026-08-20 10:10:05.092	2026-08-20 10:11:21.499	\N			09120000001@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04oo0008xvhldysumsj2	فاطمه	یعقوبی	09120000002	EDUCATION_OFFICER	t	\N	0	2026-08-20 10:10:05.112	2026-08-20 10:11:21.538	\N			09120000002@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04p80009xvhldzhqkhen	سینا	غمصاریان	09120000003	FINANCIAL_OFFICER	t	\N	0	2026-08-20 10:10:05.132	2026-08-20 10:11:21.577	\N			09120000003@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04ps000axvhlp7eheyno	سید حسین	بنی طبا	09120000004	MENTOR	t	\N	0	2026-08-20 10:10:05.152	2026-08-20 10:11:21.617	\N			09120000004@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt1d04qb000bxvhl72gu91dh	نجیبه	رمضان‌زاده	09120000005	DEPT_MANAGER	t	\N	0	2026-08-20 10:10:05.172	2026-08-20 10:11:21.656	MANAGEMENT			09120000005@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmt4b17t70000xvm5a1dq9rus	تست	کاربر	pending-1787398109479	SALES_AGENT	t	\N	0	2026-08-22 11:38:15.116	2026-08-22 11:38:15.116	MANAGEMENT			test@example.com	scrypt$16384$8$1$12OVV2lUfxv17YoP4XDmQw==$IwdS2ZNrxDL2hqZSzTtZWzJRBTw+DmLNB87bBp4rstK3yvHaiTEDfuItliSthf0+SbJcma4hnaR88uE/KieZZw==	STANDARD	t
cmt1d04ig0000xvhlq5w8vzw5	علی	محمدی	09121234567	ADMIN	t	AMIN-علی-7754	0	2026-08-20 10:10:04.889	2026-08-24 18:18:23.034	\N			admin	scrypt$16384$8$1$xVZdxDuDhzJpQs1zCo2WbQ==$cLfp9rlO8rrv3OirzHJxFvVip5T+DLRMBsUHLoFtkX1sxjVC145HZ1rUy9IchsdwhJGc+pdPxiepiaYMzQrTeQ==	STANDARD	t
cmtb33smh0001ju043916t8oi	موسسه آموزش عالی	امین	09150066349	SALES_AGENT	t	\N	0	2026-08-27 05:30:41.705	2026-08-27 05:30:41.705	MANAGEMENT			amininst1@gmail.com	scrypt$16384$8$1$CMjcyzTRIdCKOJ5dVBzzXA==$eGEM3nulbur0L/2oqDh/pnezzglvGansgxcFysxfbLdsqIgcqLM9LNd+N+gyfTWyjEbnbrBpin6UUKfyXqDZww==	STANDARD	t
cmt4b6xqn0000l404o53pj3z9	سینا	میثمی	09158176009	SALES_AGENT	f	\N	0	2026-08-22 11:42:42	2026-08-27 11:48:23.057	REAL_ESTATE			sinameysami8@gmail.com	scrypt$16384$8$1$eWWcq55XHj3GJNCmkC7yDg==$jsPbsnBoptXLWYdWwooV3xTZ+FTlpjzC3N3SjDpFD4CVZFyT03L3016KgY1YoLbxJwqVmGqG4CrXjOBly8jf8g==	STANDARD	t
cmt1d04rd000cxvhlscq81von	محمد	عدالت	09120000006	DEPT_MANAGER	f	\N	0	2026-08-20 10:10:05.21	2026-09-14 05:11:09.061	FINANCE			09120000006@demo.local	scrypt$16384$8$1$ZMlamXdJgWDNrYRnPYOQ3w==$/K12BI/IwKSjEyAqvT2kKRDjhcUk3CVtBi5o6XBoc6/SNnu4w0uDBKZ5sdOqTBqUzC8ZefrroXvWHTNa+8rYyg==	STANDARD	t
cmu0sc8wq0001le042nohyuor	محمد	عدالت	۰۹۳۰۸۸۳۴۹۲۹	SALES_AGENT	f	\N	0	2026-09-14 05:11:20.859	2026-09-14 06:49:41.888	MANAGEMENT			pending-1789362607194@placeholder.local	scrypt$16384$8$1$kmhTN8i+ocTNnH14FYmtHA==$TQ998f28nfoY8g3KkcqgZ1/Vjk8Yv7xCL3kNUSzvCpDGmnuwC/0pU9JbXo6K9yDKWKVHR0xxMqrKfXb0p7A2Ag==	STANDARD	t
cmu0vusy70001l504l8ndwg7d	محمد	عدالت	09308834929	SALES_AGENT	t	\N	0	2026-09-14 06:49:45.488	2026-09-14 06:49:45.488	MANAGEMENT			edalatmohamad40@gmail.com	scrypt$16384$8$1$k92jsuaJ7ur97oq8vy0srw==$HlefZqJ0D36TZfEggewvVVh0/92TJtNNXuVInk4kl1rNkmJyt3YJ/Bezt56prMCtuUWANXIY9QhLTLUjgc9iSw==	STANDARD	t
cmu0sdwer0000l204zpkamdpb	یونس	دوست حصاری	۰۹۳۳۸۶۶۸۷۰۴	SALES_AGENT	f	\N	0	2026-09-14 05:12:37.971	2026-09-14 06:51:08.202	MANAGEMENT			pending-1789362733634@placeholder.local	scrypt$16384$8$1$o7tqTtdmU2WmWAgh3ZlZfQ==$gnk3+AsZCZVITmpdPYA8desrOa4O72170fhCScSgdHuOxSJXye60NhAoyVaOOGBtEHGsw1DmtdreuUINtAFcJw==	STANDARD	t
cmu0vwmel000bl504ssx7t2ic	یونس	دوست حصاری	09338668704	SALES_AGENT	t	\N	0	2026-09-14 06:51:10.317	2026-09-14 06:51:10.317	MANAGEMENT			younes.dh1381@gmail.com	scrypt$16384$8$1$fzn4s+Ap7ZWRiZpS2EFaLQ==$Y+Rk3BP8MaVkMOmTmTf//pjhyq2mZclE2P2MFth6jbqZOnAoa1c/ffybXRpIFbFDJU0HOoHO6Z/4YKTM997omQ==	STANDARD	t
cmt7ki70t0000lg04corpsid8	علی	سجادی	09155176009	SALES_AGENT	f	\N	0	2026-08-24 18:26:42.318	2026-09-19 11:36:07.608	MANAGEMENT			pending-1787595312646@placeholder.local	scrypt$16384$8$1$MKAU7Ix1OVLG8M24W7+yww==$jLEYf3dgDQ9/qb2dpwRDMmnF6bOdv2NSPTHVmTmAjVeNWiHiuoIm6wbLJXfEV/lfcfWXu3/2JecyBL7sqDi1nw==	STANDARD	t
cmtb5iccp0000jm041tiot8xw	محمد	بابایی	09158154545	SALES_AGENT	f	\N	0	2026-08-27 06:37:59.689	2026-09-19 11:36:16.077	MANAGEMENT			pending-1787812648631@placeholder.local	scrypt$16384$8$1$uzNuoS8BvEF6sTqHdFNzZg==$ZjLSb2NyTTMgBpmDT1z6DaImvqC5vYgY3/not2HnwwCyQ2aMh2hxkeIcNefZAgkeHbFNbx3zKRqADRGV0ew63g==	STANDARD	t
cmtb6c30l0000l5047m2y4hz1	سلام	خممییب	09158888888	SALES_AGENT	f	\N	0	2026-08-27 07:01:07.269	2026-09-19 11:36:30.261	MANAGEMENT			pending-1787814049766@placeholder.local	scrypt$16384$8$1$I/G/BjoMuSUk59+EsORjbQ==$D1DwB7nqWx0EuYF/4aXBiTxfVwzvxKyk8AhGTVfSpykxywzBlS0rtXSfskKzEJ5s6RKQU6F4YFL4hYO5X7S/hQ==	STANDARD	t
cmtqxf58p000djl04zxpavq1w	علی	علیم	09158885445	SALES_MANAGER	f	\N	0	2026-09-07 07:35:52.393	2026-09-19 11:36:34.859	MANAGEMENT			thetruesxiiina@gmail.com	scrypt$16384$8$1$PiJVsGZ6nlFbbeCgXXVbEA==$EXOusTOfGLV4f/B35UI1CvGFqeiSzigbeXIDzlFhJUFft52DKvzYu/x+v0vwohNo3qya5z1tkGtk73OYp606ww==	STANDARD	t
\.


--
-- Name: Account Account_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_pkey" PRIMARY KEY (id);


--
-- Name: ActivityLog ActivityLog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ActivityLog"
    ADD CONSTRAINT "ActivityLog_pkey" PRIMARY KEY (id);


--
-- Name: ClassSession ClassSession_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ClassSession"
    ADD CONSTRAINT "ClassSession_pkey" PRIMARY KEY (id);


--
-- Name: Commission Commission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Commission"
    ADD CONSTRAINT "Commission_pkey" PRIMARY KEY (id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (id);


--
-- Name: Enrollment Enrollment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_pkey" PRIMARY KEY (id);


--
-- Name: Interaction Interaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Interaction"
    ADD CONSTRAINT "Interaction_pkey" PRIMARY KEY (id);


--
-- Name: Lead Lead_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Lead"
    ADD CONSTRAINT "Lead_pkey" PRIMARY KEY (id);


--
-- Name: PasswordResetToken PasswordResetToken_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_pkey" PRIMARY KEY (id);


--
-- Name: Payment Payment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_pkey" PRIMARY KEY (id);


--
-- Name: PurchaseRequest PurchaseRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseRequest"
    ADD CONSTRAINT "PurchaseRequest_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: SignupRequest SignupRequest_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SignupRequest"
    ADD CONSTRAINT "SignupRequest_pkey" PRIMARY KEY (id);


--
-- Name: Task Task_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_pkey" PRIMARY KEY (id);


--
-- Name: Teacher Teacher_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Teacher"
    ADD CONSTRAINT "Teacher_pkey" PRIMARY KEY (id);


--
-- Name: Ticket Ticket_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Account_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Account_provider_providerAccountId_key" ON public."Account" USING btree (provider, "providerAccountId");


--
-- Name: Commission_referee_lead_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Commission_referee_lead_id_key" ON public."Commission" USING btree (referee_lead_id);


--
-- Name: Enrollment_course_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Enrollment_course_id_idx" ON public."Enrollment" USING btree (course_id);


--
-- Name: Enrollment_payment_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Enrollment_payment_status_idx" ON public."Enrollment" USING btree (payment_status);


--
-- Name: Enrollment_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Enrollment_student_id_idx" ON public."Enrollment" USING btree (student_id);


--
-- Name: Interaction_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Interaction_agent_id_idx" ON public."Interaction" USING btree (agent_id);


--
-- Name: Interaction_lead_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Interaction_lead_id_idx" ON public."Interaction" USING btree (lead_id);


--
-- Name: Interaction_next_followup_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Interaction_next_followup_date_idx" ON public."Interaction" USING btree (next_followup_date);


--
-- Name: Lead_assigned_to_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Lead_assigned_to_id_idx" ON public."Lead" USING btree (assigned_to_id);


--
-- Name: Lead_department_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Lead_department_idx" ON public."Lead" USING btree (department);


--
-- Name: Lead_phone_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Lead_phone_number_idx" ON public."Lead" USING btree (phone_number);


--
-- Name: Lead_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Lead_status_idx" ON public."Lead" USING btree (status);


--
-- Name: Lead_target_course_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Lead_target_course_id_idx" ON public."Lead" USING btree (target_course_id);


--
-- Name: PasswordResetToken_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "PasswordResetToken_token_key" ON public."PasswordResetToken" USING btree (token);


--
-- Name: Payment_enrollment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Payment_enrollment_id_idx" ON public."Payment" USING btree (enrollment_id);


--
-- Name: Session_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "Session_sessionToken_key" ON public."Session" USING btree ("sessionToken");


--
-- Name: SignupRequest_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "SignupRequest_email_key" ON public."SignupRequest" USING btree (email);


--
-- Name: Task_agent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Task_agent_id_idx" ON public."Task" USING btree (agent_id);


--
-- Name: Task_due_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Task_due_date_idx" ON public."Task" USING btree (due_date);


--
-- Name: Ticket_student_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "Ticket_student_id_idx" ON public."Ticket" USING btree (student_id);


--
-- Name: User_department_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "User_department_idx" ON public."User" USING btree (department);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_phone_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_phone_number_key" ON public."User" USING btree (phone_number);


--
-- Name: User_referral_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "User_referral_code_key" ON public."User" USING btree (referral_code);


--
-- Name: Account Account_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Account"
    ADD CONSTRAINT "Account_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClassSession ClassSession_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ClassSession"
    ADD CONSTRAINT "ClassSession_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Commission Commission_referee_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Commission"
    ADD CONSTRAINT "Commission_referee_lead_id_fkey" FOREIGN KEY (referee_lead_id) REFERENCES public."Lead"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Commission Commission_referrer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Commission"
    ADD CONSTRAINT "Commission_referrer_id_fkey" FOREIGN KEY (referrer_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Enrollment Enrollment_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Enrollment Enrollment_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Enrollment"
    ADD CONSTRAINT "Enrollment_student_id_fkey" FOREIGN KEY (student_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Interaction Interaction_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Interaction"
    ADD CONSTRAINT "Interaction_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Interaction Interaction_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Interaction"
    ADD CONSTRAINT "Interaction_lead_id_fkey" FOREIGN KEY (lead_id) REFERENCES public."Lead"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Lead Lead_assigned_to_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Lead"
    ADD CONSTRAINT "Lead_assigned_to_id_fkey" FOREIGN KEY (assigned_to_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Lead Lead_referred_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Lead"
    ADD CONSTRAINT "Lead_referred_by_id_fkey" FOREIGN KEY (referred_by_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Lead Lead_target_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Lead"
    ADD CONSTRAINT "Lead_target_course_id_fkey" FOREIGN KEY (target_course_id) REFERENCES public."Course"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PasswordResetToken PasswordResetToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PasswordResetToken"
    ADD CONSTRAINT "PasswordResetToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Payment Payment_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Payment"
    ADD CONSTRAINT "Payment_enrollment_id_fkey" FOREIGN KEY (enrollment_id) REFERENCES public."Enrollment"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: PurchaseRequest PurchaseRequest_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PurchaseRequest"
    ADD CONSTRAINT "PurchaseRequest_requester_id_fkey" FOREIGN KEY (requester_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_agent_id_fkey" FOREIGN KEY (agent_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Task Task_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Task"
    ADD CONSTRAINT "Task_lead_id_fkey" FOREIGN KEY (lead_id) REFERENCES public."Lead"(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Ticket Ticket_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."Ticket"
    ADD CONSTRAINT "Ticket_student_id_fkey" FOREIGN KEY (student_id) REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict OyOzujgOSvEwVFhWvBYvyWJcVO84oBtT1aRRTFNr7dMQMwmR5yjavatAxsd59rX

