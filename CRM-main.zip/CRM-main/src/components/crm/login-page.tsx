'use client'

import { useState, useEffect, useRef } from 'react'
import { GraduationCap, Phone, LogIn, Users, Shield, Headphones, BookOpen, Sparkles, Loader2, ArrowRight, CheckCircle2, Landmark } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Separator } from '@/components/ui/separator'
import { Checkbox } from '@/components/ui/checkbox'

import { useCRMStore, type CurrentUser } from '@/lib/store'

interface DemoUser {
  id: string
  first_name: string
  last_name: string
  role: string
  phone_number: string
}

const roleColors: Record<string, string> = {
  ADMIN: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
  SALES_MANAGER: 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 border-teal-200 dark:border-teal-800',
  SALES_AGENT: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800',
  STUDENT: 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 border-sky-200 dark:border-sky-800',
  EDUCATION_OFFICER: 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border-blue-200 dark:border-blue-800',
  FINANCIAL_OFFICER: 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border-purple-200 dark:border-purple-800',
  MENTOR: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
  DEPT_MANAGER: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-200 dark:border-rose-800',
}

const roleLabels: Record<string, string> = {
  ADMIN: 'ادمین',
  SALES_MANAGER: 'مدیر فروش',
  SALES_AGENT: 'کارشناس فروش',
  STUDENT: 'دانش‌پذیر',
  EDUCATION_OFFICER: 'مسئول آموزش',
  FINANCIAL_OFFICER: 'مسئول امور مالی',
  MENTOR: 'منتور',
  DEPT_MANAGER: 'مدیر دپارتمان',
}

const roleIcons: Record<string, React.ElementType> = {
  ADMIN: Shield,
  SALES_MANAGER: Users,
  SALES_AGENT: Headphones,
  STUDENT: BookOpen,
  EDUCATION_OFFICER: GraduationCap,
  FINANCIAL_OFFICER: Landmark,
  MENTOR: BookOpen,
  DEPT_MANAGER: Users,
}

const roleGroupLabels: Record<string, string> = {
  ADMIN: 'مدیریت ارشد',
  SALES_MANAGER: 'مدیریت فروش',
  SALES_AGENT: 'کارشناسان فروش',
  STUDENT: 'دانش‌پذیران نمونه',
  EDUCATION_OFFICER: 'امور آموزشی',
  FINANCIAL_OFFICER: 'امور مالی',
  MENTOR: 'منتورها',
  DEPT_MANAGER: 'مدیران دپارتمان',
}

const roleGroupOrder = ['ADMIN', 'DEPT_MANAGER', 'EDUCATION_OFFICER', 'FINANCIAL_OFFICER', 'MENTOR', 'SALES_MANAGER', 'SALES_AGENT', 'STUDENT']

const DIAGNOSTIC_QUESTIONS = [
  {
    id: 1,
    question: 'حوزه فعالیت و صنعت کسب‌وکار شما چیست؟',
    options: ['خدماتی / مشاوره و آموزش', 'تولیدی / کارگاهی و صنعتی', 'املاک / پیمانکاری و ساخت', 'فروشگاهی / بنکداری و آنلاین‌شاپ', 'سایر موارد']
  },
  {
    id: 2,
    question: 'تعداد پرسنل فعال در مجموعه شما چند نفر است؟',
    options: ['۱ تا ۵ نفر (کسب‌وکار نوپا یا کوچک)', '۶ تا ۱۵ نفر (کسب‌وکار در حال رشد)', '۱۶ تا ۵۰ نفر (متوسط)', 'بیش از ۵۰ نفر (سازمان بزرگ)']
  },
  {
    id: 3,
    question: 'بزرگترین چالش فعلی کسب‌وکار شما چیست؟',
    options: ['کاهش فروش، بازاریابی ضعیف و رقبای جدید', 'چالش هماهنگی پرسنل، کار تیمی و مدیریت منابع انسانی', 'مشکلات حقوقی، قراردادهای غیرامن و ریسک قضایی', 'نقص در بودجه‌بندی، جریان نقدی و مدیریت مالی']
  },
  {
    id: 4,
    question: 'فرآیندهای کاری شما چقدر مکانیزه و سیستماتیک است؟',
    options: ['کاملاً سنتی (وابسته به کاغذ، حضور و حافظه مدیر)', 'نیمه‌سیستماتیک (استفاده از ابزارهای عمومی و شبکه‌های اجتماعی)', 'کاملاً مکانیزه (دارای CRM، نرم‌افزارهای تخصصی و فرآیندهای مکتوب)']
  },
  {
    id: 5,
    question: 'هدف نهایی شما از شرکت در دوره‌های آموزشی چیست؟',
    options: ['افزایش سودآوری، مشتری بیشتر و رشد برند', 'سیستم‌سازی و خروج خودم از کارهای اجرایی روزانه', 'پیشگیری از دعاوی حقوقی و جرایم قراردادی سنگین', 'دریافت مدرک معتبر وزارت علوم جهت ارتقاء شغلی یا مهاجرت']
  }
]

export default function LoginPage({ initialResetToken }: { initialResetToken?: string } = {}) {
  const { login } = useCRMStore()
  const [email, setEmail] = useState('')
  const [phoneNumber, setPhoneNumber] = useState('')
  const [password, setPassword] = useState('')
  const [rememberMe, setRememberMe] = useState(false)
  const [users, setUsers] = useState<DemoUser[]>([])
  const [loading, setLoading] = useState(true)
  const [loginSuccess, setLoginSuccess] = useState(false)

  // Tab/Mode state
  const [mode, setMode] = useState<'login' | 'register' | 'diagnostic' | 'staff-signup' | 'reset-password'>(
    initialResetToken ? 'reset-password' : 'login'
  )

  // Password reset form state (admin sends this link out-of-band)
  const [resetNewPassword, setResetNewPassword] = useState('')
  const [resetConfirmPassword, setResetConfirmPassword] = useState('')
  const [submittingReset, setSubmittingReset] = useState(false)
  const [resetDone, setResetDone] = useState(false)
  
  // Registration form state
  const [regFirstName, setRegFirstName] = useState('')
  const [regLastName, setRegLastName] = useState('')
  const [regPhone, setRegPhone] = useState('')
  const [regCourseId, setRegCourseId] = useState('')
  const [regReferralCode, setRegReferralCode] = useState('')
  const [courses, setCourses] = useState<any[]>([])
  const [submittingReg, setSubmittingReg] = useState(false)

  // Staff signup form state
  const [staffFirstName, setStaffFirstName] = useState('')
  const [staffLastName, setStaffLastName] = useState('')
  const [staffEmail, setStaffEmail] = useState('')
  const [staffPhone, setStaffPhone] = useState('')
  const [staffPassword, setStaffPassword] = useState('')
  const [staffDept, setStaffDept] = useState('MANAGEMENT')
  const [submittingStaffReg, setSubmittingStaffReg] = useState(false)

  // Business Diagnostic state
  const [diagStep, setDiagStep] = useState(0) // 0: basic info, 1-5: questions, 6: loading, 7: report
  const [diagFirstName, setDiagFirstName] = useState('')
  const [diagLastName, setDiagLastName] = useState('')
  const [diagPhone, setDiagPhone] = useState('')
  const [diagReferralCode, setDiagReferralCode] = useState('')
  const [diagAnswers, setDiagAnswers] = useState<Record<string, string>>({})
  const [diagReport, setDiagReport] = useState('')
  const [diagScore, setDiagScore] = useState(0)
  const [diagPrimaryGap, setDiagPrimaryGap] = useState('')
  const [loadingTextIndex, setLoadingTextIndex] = useState(0)

  // Title typing effect state
  const fullTitleText = 'آموزش عالی آزاد امین'
  const [displayedTitle, setDisplayedTitle] = useState('')
  const [titleComplete, setTitleComplete] = useState(false)
  const typingTimer = useRef<NodeJS.Timeout | null>(null)

  // Fetch users for quick login (only when DEMO_AUTH=1 is enabled).
  useEffect(() => {
    async function fetchUsers() {
      try {
        const res = await fetch('/api/auth/demo-users')
        if (res.ok) {
          const data = await res.json()
          setUsers(Array.isArray(data) ? data : [])
        } else {
          setUsers([])
        }
      } catch {
        toast.error('خطا در بارگذاری کاربران دمو')
        setUsers([])
      } finally {
        setLoading(false)
      }
    }
    fetchUsers()
  }, [])

  // Fetch active courses for registration dropdown
  useEffect(() => {
    async function fetchCourses() {
      try {
        const res = await fetch('/api/public/courses')
        if (res.ok) {
          const data = await res.json()
          setCourses(data)
        }
      } catch (err) {
        console.error('Failed to load courses:', err)
      }
    }
    fetchCourses()
  }, [])

  // Detect referral parameter ?ref=... in URL
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search)
      const ref = params.get('ref')
      if (ref) {
        setRegReferralCode(ref)
        setDiagReferralCode(ref)
        setMode('register') // Automatically open registration if clicked a referral link
        toast.success(`کد معرف "${ref}" با موفقیت شناسایی شد.`)
      }
    }
  }, [])

  // Header typing animation
  useEffect(() => {
    let index = 0
    setDisplayedTitle('')
    setTitleComplete(false)

    if (typingTimer.current) clearInterval(typingTimer.current)

    typingTimer.current = setInterval(() => {
      if (index < fullTitleText.length) {
        setDisplayedTitle((prev) => prev + fullTitleText.charAt(index))
        index++
      } else {
        setTitleComplete(true)
        if (typingTimer.current) clearInterval(typingTimer.current)
      }
    }, 90)

    return () => {
      if (typingTimer.current) clearInterval(typingTimer.current)
    }
  }, [])

  // Alternating loading text for diagnostic step 6
  useEffect(() => {
    if (diagStep !== 6) return
    const texts = [
      'هوش مصنوعی در حال تحلیل پاسخ‌های کسب‌وکار شماست...',
      'در حال بررسی ساختار سازمانی و ریسک‌های مدیریت تیمی...',
      'تطبیق چالش‌ها با سرفصل‌های دپارتمان‌های موسسه امین...',
      'در حال فرمول‌بندی راهکارهای عملیاتی فوری (Quick Wins)...',
      'نگارش گزارش نهایی عارضه‌یابی کسب‌وکار...'
    ]
    const timer = setInterval(() => {
      setLoadingTextIndex((prev) => (prev + 1) % texts.length)
    }, 2500)
    return () => clearInterval(timer)
  }, [diagStep])

  const handleQuickLogin = async (user: DemoUser) => {
    setLoginSuccess(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id }),
      })
      if (!res.ok) {
        setLoginSuccess(false)
        toast.error('ورود ناموفق بود')
        return
      }
      const json = await res.json()
      const u = json.user
      setTimeout(() => {
        login({
          id: u.id,
          first_name: u.first_name,
          last_name: u.last_name,
          role: u.role,
          phone_number: u.phone_number,
        })
      }, 400)
    } catch {
      setLoginSuccess(false)
      toast.error('خطا در ارتباط با سرور')
    }
  }

  const handleCredentialsLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault()

    const trimmedEmail = email.trim().toLowerCase()
    const trimmedPhone = phoneNumber.trim()
    const pass = password.trim()

    if (!trimmedEmail) {
      toast.error('لطفاً ایمیل خود را وارد کنید')
      return
    }
    if (!pass) {
      toast.error('لطفاً رمز عبور را وارد کنید')
      return
    }

    setLoginSuccess(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: trimmedEmail, password: pass }),
      })

      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        setLoginSuccess(false)
        toast.error(err.error || 'ورود ناموفق بود')
        return
      }

      const json = await res.json()
      const u = json.user
      setTimeout(() => {
        login({
          id: u.id,
          first_name: u.first_name,
          last_name: u.last_name,
          role: u.role,
          phone_number: u.phone_number ?? trimmedPhone,
        })
      }, 400)
    } catch (err) {
      console.error(err)
      setLoginSuccess(false)
      toast.error('ارتباط با سرور برقرار نشد')
    }
  }

  const handleRegisterLead = async () => {
    if (!regFirstName.trim() || !regLastName.trim() || !regPhone.trim() || !regCourseId) {
      toast.error('لطفاً همه فیلدهای اجباری را پر کنید')
      return
    }
    setSubmittingReg(true)
    try {
      const res = await fetch('/api/public/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          first_name: regFirstName.trim(),
          last_name: regLastName.trim(),
          phone_number: regPhone.trim(),
          target_course_id: regCourseId,
          referral_code: regReferralCode.trim() || undefined,
        })
      })

      if (res.ok) {
        toast.success('درخواست مشاوره و ثبت‌نام شما با موفقیت ارسال شد. کارشناسان ما به زودی با شما تماس می‌گیرند.')
        setRegFirstName('')
        setRegLastName('')
        setRegPhone('')
        setRegCourseId('')
        setMode('login')
      } else {
        const errJson = await res.json()
        toast.error(errJson.error || 'خطا در ثبت اطلاعات لید')
      }
    } catch (err) {
      console.error(err)
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSubmittingReg(false)
    }
  }

  const handleStaffSignup = async () => {
    if (!staffFirstName.trim() || !staffLastName.trim() || !staffPhone.trim() || !staffEmail.trim() || !staffPassword.trim()) {
      toast.error('لطفاً همه فیلدهای اجباری را پر کنید')
      return
    }
    if (staffPassword.length < 8) {
      toast.error('رمز عبور باید حداقل ۸ کاراکتر باشد')
      return
    }
    setSubmittingStaffReg(true)
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          first_name: staffFirstName.trim(),
          last_name: staffLastName.trim(),
          phone_number: staffPhone.trim(),
          email: staffEmail.trim(),
          password: staffPassword.trim(),
          desired_department: staffDept || undefined,
        })
      })

      if (res.ok) {
        toast.success('درخواست ثبت‌نام شما با موفقیت ارسال شد و پس از تایید مدیریت فعال خواهد شد.')
        setStaffFirstName('')
        setStaffLastName('')
        setStaffPhone('')
        setStaffEmail('')
        setStaffPassword('')
        setMode('login')
      } else {
        const errJson = await res.json()
        let errorMessage = 'خطا در ثبت‌نام'
        if (errJson.error) {
          if (typeof errJson.error === 'object') {
            errorMessage = Object.values(errJson.error).flat().join(' - ')
          } else {
            errorMessage = errJson.error
          }
        }
        toast.error(errorMessage)
      }
    } catch (err) {
      console.error(err)
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSubmittingStaffReg(false)
    }
  }

  const handleConfirmPasswordReset = async () => {
    if (!resetNewPassword || resetNewPassword.length < 8) {
      toast.error('رمز عبور باید حداقل ۸ کاراکتر باشد')
      return
    }
    if (resetNewPassword !== resetConfirmPassword) {
      toast.error('رمز عبور و تکرار آن یکسان نیستند')
      return
    }
    setSubmittingReset(true)
    try {
      const res = await fetch('/api/auth/password-reset/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: initialResetToken, newPassword: resetNewPassword }),
      })
      const json = await res.json()
      if (res.ok) {
        setResetDone(true)
        toast.success('رمز عبور با موفقیت تغییر کرد. اکنون می‌توانید وارد شوید.')
      } else {
        toast.error(json.error || 'لینک بازیابی نامعتبر یا منقضی شده است')
      }
    } catch (err) {
      console.error(err)
      toast.error('ارتباط با سرور برقرار نشد')
    } finally {
      setSubmittingReset(false)
    }
  }

  // Diagnostic handlers
  const handleStartDiagnostic = () => {
    if (!diagFirstName.trim() || !diagLastName.trim() || !diagPhone.trim()) {
      toast.error('لطفاً نام، نام خانوادگی و شماره تماس خود را وارد کنید')
      return
    }
    setDiagStep(1)
  }

  const handleSelectDiagOption = async (questionText: string, option: string) => {
    const newAnswers = { ...diagAnswers, [questionText]: option }
    setDiagAnswers(newAnswers)

    if (diagStep < 5) {
      setDiagStep(diagStep + 1)
    } else {
      // Last step answered, trigger API call
      setDiagStep(6) // loading step
      try {
        const res = await fetch('/api/ai/diagnostic', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            first_name: diagFirstName.trim(),
            last_name: diagLastName.trim(),
            phone_number: diagPhone.trim(),
            answers: newAnswers,
            referral_code: diagReferralCode.trim() || undefined
          })
        })

        if (res.ok) {
          const json = await res.json()
          setDiagReport(json.text)
          setDiagScore(json.score)
          setDiagPrimaryGap(json.primaryGap)
          setDiagStep(7) // show report step
          toast.success('گزارش عارضه‌یابی شما صادر گردید.')
        } else {
          toast.error('خطا در ارتباط با هوش مصنوعی. لطفاً مجدداً تلاش کنید.')
          setDiagStep(5)
        }
      } catch (err) {
        console.error(err)
        toast.error('خطا در شبکه. ارتباط برقرار نشد.')
        setDiagStep(5)
      }
    }
  }

  const handleResetDiagnostic = () => {
    setDiagFirstName('')
    setDiagLastName('')
    setDiagPhone('')
    setDiagAnswers({})
    setDiagReport('')
    setDiagStep(0)
    setMode('login')
  }

  // Dynamic Persian year
  const currentPersianYear = new Intl.DateTimeFormat('fa-IR', { year: 'numeric' }).format(new Date())

  // Group users by role
  const groupedUsers: Record<string, DemoUser[]> = {}
  for (const user of users) {
    if (!groupedUsers[user.role]) groupedUsers[user.role] = []
    groupedUsers[user.role].push(user)
  }

  const loadingTexts = [
    'هوش مصنوعی در حال تحلیل پاسخ‌های کسب‌وکار شماست...',
    'در حال بررسی ساختار سازمانی و ریسک‌های مدیریت تیمی...',
    'تطبیق چالش‌ها با سرفصل‌های دپارتمان‌های موسسه امین...',
    'در حال فرمول‌بندی راهکارهای عملیاتی فوری (Quick Wins)...',
    'نگارش گزارش نهایی عارضه‌یابی کسب‌وکار...'
  ]

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex items-center justify-center p-4 relative" dir="rtl">
      {!loginSuccess ? (
        <div className="w-full max-w-xl">
          <Card className="border border-border bg-card shadow-lg rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-emerald-600 dark:bg-emerald-700 p-8 text-center text-white">
              <div className="inline-flex items-center justify-center size-14 rounded-xl bg-white/10 mb-3">
                <GraduationCap className="size-8 text-white" />
              </div>
              <h1 className="text-xl font-bold text-white mb-1">
                {displayedTitle}
                {!titleComplete && <span className="animate-pulse">|</span>}
              </h1>
              <p className="text-emerald-100 text-xs">سامانه هوشمند ارتباط با مشتری (CRM)</p>
            </div>

            <CardContent className="p-6 sm:p-8">
              {mode === 'login' ? (
                <>
                  {/* Login Title */}
                  <div className="text-center mb-6">
                    <h2 className="text-lg font-bold text-foreground">ورود به سیستم</h2>
                    <p className="text-xs text-muted-foreground mt-1">
                      برای دسترسی به پنل مدیریت، ایمیل و رمز عبور خود را وارد کنید
                    </p>
                  </div>

                  {/* Credentials Login Form */}
                  <form onSubmit={handleCredentialsLogin} className="space-y-4 mb-6">
                    <div className="space-y-1.5">
                      <Label htmlFor="email-input" className="text-xs font-medium text-muted-foreground">
                        ایمیل
                      </Label>
                      <div className="relative">
                        <Phone className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                        <Input
                          id="email-input"
                          name="email"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="[email protected]"
                          dir="ltr"
                          className="pr-9 h-10 text-xs"
                          autoComplete="username"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <Label htmlFor="current-password" className="text-xs font-medium text-muted-foreground">
                        رمز عبور
                      </Label>
                      <div className="relative">
                        <Shield className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                        <Input
                          id="current-password"
                          name="password"
                          type="password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          placeholder="رمز عبور"
                          dir="ltr"
                          className="pr-9 h-10 text-xs"
                          autoComplete="current-password"
                          required
                        />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1">
                        * حساب شما پس از تایید توسط مدیر فعال خواهد شد.
                      </p>
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white gap-2 h-10 shadow-none font-medium text-xs mt-2"
                    >
                      <LogIn className="size-4" />
                      ورود به پنل کاربری
                    </Button>
                    
                    {/* Remember me + Forgot password */}
                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          id="remember"
                          checked={rememberMe}
                          onCheckedChange={(checked) => setRememberMe(checked === true)}
                          className="data-[state=checked]:bg-emerald-600 data-[state=checked]:border-emerald-600 size-4"
                        />
                        <Label htmlFor="remember" className="text-xs text-muted-foreground cursor-pointer">
                          مرا به خاطر بسپار
                        </Label>
                      </div>
                      <button
                        type="button"
                        className="text-xs text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 dark:hover:text-emerald-300 hover:underline"
                        onClick={() => toast.info('برای بازیابی رمز عبور با مدیر سیستم تماس بگیرید.')}
                      >
                        فراموشی رمز عبور؟
                      </button>
                    </div>
                  </form>

                  {/* Client choices (Register or AI Diagnostics or Staff Signup) */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
                    <button
                      type="button"
                      onClick={() => setMode('register')}
                      className="text-[10px] sm:text-xs text-emerald-600 hover:underline font-semibold bg-emerald-50 dark:bg-emerald-950/20 px-3 py-2 rounded-lg border border-emerald-100 dark:border-emerald-900/30 text-center"
                    >
                      ثبت درخواست مشاوره معمولی
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setMode('diagnostic')
                        setDiagStep(0)
                      }}
                      className="text-[10px] sm:text-xs text-amber-700 hover:underline font-semibold bg-amber-50 dark:bg-amber-950/20 px-3 py-2 rounded-lg border border-amber-100 dark:border-amber-900/30 flex items-center justify-center gap-1"
                    >
                      <Sparkles className="size-3 text-amber-600 shrink-0" />
                      عارضه‌یاب هوشمند کسب‌وکار
                    </button>
                    <button
                      type="button"
                      onClick={() => setMode('staff-signup')}
                      className="text-[10px] sm:text-xs text-blue-600 hover:underline font-semibold bg-blue-50 dark:bg-blue-950/20 px-3 py-2 rounded-lg border border-blue-100 dark:border-blue-900/30 text-center"
                    >
                      ثبت‌نام همکار جدید (کارشناس)
                    </button>
                  </div>

                  <div className="relative mb-6">
                    <Separator />
                    <span className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-card px-3 text-xs text-muted-foreground">
                      یا ورود سریع
                    </span>
                  </div>

                  {/* Quick Login Section */}
                  <div>
                    <h3 className="text-xs font-semibold text-muted-foreground mb-4 flex items-center gap-2">
                      <Users className="size-4 text-emerald-600" />
                      ورود سریع با انتخاب کاربر دمو
                    </h3>

                    {loading ? (
                      <div className="space-y-4">
                        {Array.from({ length: 2 }).map((_, i) => (
                          <div key={i} className="grid grid-cols-2 gap-3">
                            <div className="h-12 bg-muted rounded-xl animate-pulse" />
                            <div className="h-12 bg-muted rounded-xl animate-pulse" />
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="max-h-72 overflow-y-auto pr-1">
                        <div className="space-y-5">
                          {roleGroupOrder.map((role) => {
                            const group = groupedUsers[role]
                            if (!group || group.length === 0) return null

                            const RoleIcon = roleIcons[role] || Users

                            return (
                              <div key={role}>
                                <div className="flex items-center gap-2 mb-2">
                                  <RoleIcon className="size-3.5 text-muted-foreground" />
                                  <span className="text-xs font-semibold text-muted-foreground">
                                    {roleGroupLabels[role]}
                                  </span>
                                  <Badge variant="secondary" className="text-[9px] px-1 py-0 h-4 min-w-4 flex items-center justify-center">
                                    {group.length}
                                  </Badge>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                  {group.map((user) => (
                                    <button
                                      key={user.id}
                                      onClick={() => handleQuickLogin(user)}
                                      className="flex items-center gap-3 p-3 rounded-xl border border-border bg-card hover:bg-emerald-50 dark:hover:bg-emerald-950/20 hover:border-emerald-500 transition-colors text-right w-full group"
                                    >
                                      <div className="size-9 rounded-full bg-emerald-100 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center flex-shrink-0">
                                        <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300">
                                          {user.first_name[0]}
                                        </span>
                                      </div>
                                      <div className="flex-1 min-w-0">
                                        <p className="text-xs font-medium truncate">
                                          {user.first_name} {user.last_name}
                                        </p>
                                        <Badge
                                          variant="outline"
                                          className={`text-[9px] px-1 py-0 mt-0.5 ${roleColors[user.role] || ''}`}
                                        >
                                          {roleLabels[user.role] || user.role}
                                        </Badge>
                                      </div>
                                      <LogIn className="size-3.5 text-emerald-600 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </button>
                                  ))}
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </>
              ) : mode === 'register' ? (
                <div className="space-y-4">
                  {/* Registration Title */}
                  <div className="text-center mb-4">
                    <h2 className="text-lg font-bold text-foreground">ثبت درخواست مشاوره آموزشی</h2>
                    <p className="text-xs text-muted-foreground mt-1">
                      اطلاعات تماس خود را وارد کنید تا کارشناسان موسسه امین با شما تماس بگیرند
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-first-name" className="text-xs text-muted-foreground">نام *</Label>
                      <Input
                        id="reg-first-name"
                        value={regFirstName}
                        onChange={(e) => setRegFirstName(e.target.value)}
                        placeholder="مثال: علی"
                        className="h-10 text-xs"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="reg-last-name" className="text-xs text-muted-foreground">نام خانوادگی *</Label>
                      <Input
                        id="reg-last-name"
                        value={regLastName}
                        onChange={(e) => setRegLastName(e.target.value)}
                        placeholder="مثال: اکبری"
                        className="h-10 text-xs"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="reg-phone" className="text-xs text-muted-foreground">شماره تماس *</Label>
                    <Input
                      id="reg-phone"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                      dir="ltr"
                      className="h-10 text-xs"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">دوره آموزشی مورد علاقه *</Label>
                    <select
                      value={regCourseId}
                      onChange={(e) => setRegCourseId(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border bg-background text-xs border-input focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="">انتخاب کنید...</option>
                      {courses.map((course) => (
                        <option key={course.id} value={course.id}>
                          {course.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="reg-code" className="text-xs text-muted-foreground">کد معرف (اختیاری)</Label>
                    <Input
                      id="reg-code"
                      value={regReferralCode}
                      onChange={(e) => setRegReferralCode(e.target.value)}
                      placeholder="در صورت داشتن معرفی، کد معرف را وارد کنید"
                      className="h-10 text-xs"
                    />
                  </div>

                  <Button
                    onClick={handleRegisterLead}
                    disabled={submittingReg}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-10 text-xs shadow-none mt-2"
                  >
                    {submittingReg ? 'در حال ثبت...' : 'ارسال درخواست مشاوره'}
                  </Button>

                  <div className="text-center pt-2">
                    <button
                      onClick={() => setMode('login')}
                      className="text-xs text-muted-foreground hover:text-emerald-600 hover:underline font-medium"
                    >
                      بازگشت به صفحه ورود کارکنان و دانش‌پذیران
                    </button>
                  </div>
                </div>
              ) : mode === 'staff-signup' ? (
                <div className="space-y-4">
                  {/* Staff Registration Title */}
                  <div className="text-center mb-4">
                    <h2 className="text-lg font-bold text-foreground">ثبت‌نام همکار جدید</h2>
                    <p className="text-xs text-muted-foreground mt-1">
                      اطلاعات خود را وارد کنید. پس از تایید توسط مدیریت، حساب شما فعال خواهد شد.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <Label htmlFor="staff-first-name" className="text-xs text-muted-foreground">نام *</Label>
                      <Input
                        id="staff-first-name"
                        value={staffFirstName}
                        onChange={(e) => setStaffFirstName(e.target.value)}
                        placeholder="مثال: رضا"
                        className="h-10 text-xs"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="staff-last-name" className="text-xs text-muted-foreground">نام خانوادگی *</Label>
                      <Input
                        id="staff-last-name"
                        value={staffLastName}
                        onChange={(e) => setStaffLastName(e.target.value)}
                        placeholder="مثال: کریمی"
                        className="h-10 text-xs"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="staff-email" className="text-xs text-muted-foreground">ایمیل *</Label>
                    <Input
                      id="staff-email"
                      type="email"
                      value={staffEmail}
                      onChange={(e) => setStaffEmail(e.target.value)}
                      placeholder="example@yahoo.com"
                      dir="ltr"
                      className="h-10 text-xs"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="staff-phone" className="text-xs text-muted-foreground">شماره تماس *</Label>
                    <Input
                      id="staff-phone"
                      value={staffPhone}
                      onChange={(e) => setStaffPhone(e.target.value)}
                      placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                      dir="ltr"
                      className="h-10 text-xs"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label htmlFor="staff-pass" className="text-xs text-muted-foreground">رمز عبور (حداقل ۸ کاراکتر) *</Label>
                    <Input
                      id="staff-pass"
                      type="password"
                      value={staffPassword}
                      onChange={(e) => setStaffPassword(e.target.value)}
                      placeholder="••••••••"
                      dir="ltr"
                      className="h-10 text-xs"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-xs text-muted-foreground">دپارتمان مورد نظر *</Label>
                    <select
                      value={staffDept}
                      onChange={(e) => setStaffDept(e.target.value)}
                      className="w-full h-10 px-3 rounded-lg border bg-background text-xs border-input focus:outline-none focus:ring-1 focus:ring-emerald-500"
                    >
                      <option value="MANAGEMENT">مدیریت</option>
                      <option value="REAL_ESTATE">مشاور املاک</option>
                      <option value="FINANCE">مالی</option>
                      <option value="LAW">حقوق</option>
                      <option value="PROJECT_MANAGEMENT">مدیریت پروژه</option>
                    </select>
                  </div>

                  <Button
                    onClick={handleStaffSignup}
                    disabled={submittingStaffReg}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-10 text-xs shadow-none mt-2"
                  >
                    {submittingStaffReg ? 'در حال ارسال درخواست...' : 'ثبت درخواست عضویت'}
                  </Button>

                  <div className="text-center pt-2">
                    <button
                      onClick={() => setMode('login')}
                      className="text-xs text-muted-foreground hover:text-emerald-600 hover:underline font-medium"
                    >
                      بازگشت به صفحه ورود کارکنان و دانش‌پذیران
                    </button>
                  </div>
                </div>
              ) : mode === 'reset-password' ? (
                <div className="space-y-4">
                  <div className="text-center mb-4">
                    <h2 className="text-lg font-bold text-foreground">تعیین رمز عبور جدید</h2>
                    <p className="text-xs text-muted-foreground mt-1">
                      این لینک توسط مدیر سیستم برای شما ارسال شده است
                    </p>
                  </div>

                  {resetDone ? (
                    <div className="text-center space-y-4">
                      <p className="text-sm text-emerald-600 font-medium">رمز عبور شما با موفقیت تغییر کرد.</p>
                      <Button
                        onClick={() => { setMode('login'); setResetDone(false) }}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-10 text-xs"
                      >
                        ورود به سیستم
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-muted-foreground">رمز عبور جدید</Label>
                        <Input
                          type="password"
                          value={resetNewPassword}
                          onChange={(e) => setResetNewPassword(e.target.value)}
                          className="h-10 text-xs"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label className="text-xs font-medium text-muted-foreground">تکرار رمز عبور جدید</Label>
                        <Input
                          type="password"
                          value={resetConfirmPassword}
                          onChange={(e) => setResetConfirmPassword(e.target.value)}
                          className="h-10 text-xs"
                        />
                      </div>
                      <Button
                        onClick={handleConfirmPasswordReset}
                        disabled={submittingReset}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-10 text-xs shadow-none mt-2"
                      >
                        {submittingReset ? 'در حال ثبت...' : 'تغییر رمز عبور'}
                      </Button>
                    </>
                  )}
                </div>
              ) : (
                /* Business Diagnostic Bot Mode */
                <div className="space-y-4">
                  {/* Step 0: Basic Information */}
                  {diagStep === 0 && (
                    <div className="space-y-4">
                      <div className="text-center mb-4">
                        <div className="inline-flex p-2.5 rounded-full bg-amber-50 dark:bg-amber-950/20 text-amber-600 mb-2">
                          <Sparkles className="size-6" />
                        </div>
                        <h2 className="text-base font-bold text-foreground">عارضه‌یاب هوشمند کسب‌وکار</h2>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                          با پاسخ به ۵ سوال کوتاه، گزارش تحلیلی اولیه عارضه‌های کسب‌وکار خود را به صورت زنده از هوش مصنوعی دریافت کنید.
                        </p>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                          <Label htmlFor="diag-first-name" className="text-xs text-muted-foreground">نام *</Label>
                          <Input
                            id="diag-first-name"
                            value={diagFirstName}
                            onChange={(e) => setDiagFirstName(e.target.value)}
                            placeholder="نام خود را وارد کنید"
                            className="h-10 text-xs"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <Label htmlFor="diag-last-name" className="text-xs text-muted-foreground">نام خانوادگی *</Label>
                          <Input
                            id="diag-last-name"
                            value={diagLastName}
                            onChange={(e) => setDiagLastName(e.target.value)}
                            placeholder="فامیلی خود را وارد کنید"
                            className="h-10 text-xs"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <Label htmlFor="diag-phone" className="text-xs text-muted-foreground">شماره تماس *</Label>
                        <Input
                          id="diag-phone"
                          value={diagPhone}
                          onChange={(e) => setDiagPhone(e.target.value)}
                          placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                          dir="ltr"
                          className="h-10 text-xs"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <Label htmlFor="diag-ref" className="text-xs text-muted-foreground">کد معرف (اختیاری)</Label>
                        <Input
                          id="diag-ref"
                          value={diagReferralCode}
                          onChange={(e) => setDiagReferralCode(e.target.value)}
                          placeholder="کد معرف سفیران"
                          className="h-10 text-xs"
                        />
                      </div>

                      <Button
                        onClick={handleStartDiagnostic}
                        className="w-full bg-amber-600 hover:bg-amber-700 text-white font-semibold h-10 text-xs shadow-none mt-2"
                      >
                        شروع ارزیابی کسب‌وکار
                        <Sparkles className="size-4 mr-1.5 shrink-0" />
                      </Button>

                      <div className="text-center pt-2">
                        <button
                          onClick={handleResetDiagnostic}
                          className="text-xs text-muted-foreground hover:underline font-medium"
                        >
                          انصراف و بازگشت به صفحه ورود
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Steps 1 to 5: Assessment Questions */}
                  {diagStep >= 1 && diagStep <= 5 && (
                    <div className="space-y-4">
                      {/* Progress bar */}
                      <div>
                        <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
                          <span>میزان پیشرفت ارزیابی</span>
                          <span>سوال {diagStep} از ۵</span>
                        </div>
                        <div className="w-full bg-accent h-1.5 rounded-full overflow-hidden">
                          <div 
                            className="bg-amber-600 h-full transition-all duration-300"
                            style={{ width: `${(diagStep / 5) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div className="py-4">
                        <Badge className="bg-amber-100 text-amber-800 border-amber-200 font-bold mb-2 text-[10px]">
                          سوال شماره {diagStep}
                        </Badge>
                        <h3 className="text-sm font-bold text-foreground leading-relaxed">
                          {DIAGNOSTIC_QUESTIONS[diagStep - 1].question}
                        </h3>
                      </div>

                      <div className="space-y-2">
                        {DIAGNOSTIC_QUESTIONS[diagStep - 1].options.map((option, idx) => (
                          <button
                            key={idx}
                            onClick={() => handleSelectDiagOption(DIAGNOSTIC_QUESTIONS[diagStep - 1].question, option)}
                            className="w-full text-right p-3.5 rounded-xl border border-border bg-card hover:bg-amber-50/40 hover:border-amber-400 dark:hover:bg-amber-950/15 transition-all text-xs font-medium leading-relaxed flex justify-between items-center group"
                          >
                            <span>{option}</span>
                            <ArrowRight className="size-4 text-amber-500 opacity-0 group-hover:opacity-100 transition-opacity rotate-180" />
                          </button>
                        ))}
                      </div>

                      <div className="pt-2 flex justify-between">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setDiagStep(prev => prev - 1)}
                          disabled={diagStep === 1}
                          className="h-8 text-xs gap-1"
                        >
                          <ArrowRight className="size-3.5" />
                          قبلی
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleResetDiagnostic}
                          className="h-8 text-xs text-muted-foreground"
                        >
                          انصراف و خروج
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Step 6: Loading */}
                  {diagStep === 6 && (
                    <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
                      <Loader2 className="size-10 animate-spin text-amber-600" />
                      <div className="space-y-1.5">
                        <h3 className="text-sm font-bold text-foreground">تحلیل هوش مصنوعی امین</h3>
                        <p className="text-xs text-muted-foreground px-6 leading-relaxed max-w-sm animate-pulse">
                          {loadingTexts[loadingTextIndex]}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Step 7: Diagnostic Report View */}
                  {diagStep === 7 && (
                    <div className="space-y-4">
                      <div className="text-center pb-2">
                        <div className="inline-flex p-1.5 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 mb-2">
                          <CheckCircle2 className="size-6" />
                        </div>
                        <h3 className="text-sm font-bold text-foreground">گزارش عارضه‌یابی صادر شد</h3>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          کیفیت وضعیت کسب‌وکار شما: <span className="font-semibold text-emerald-600">{diagScore} از ۱۰۰</span>
                        </p>
                      </div>

                      <div className="p-4 rounded-xl border bg-accent/15 max-h-80 overflow-y-auto text-xs leading-relaxed whitespace-pre-wrap text-foreground scrollbar-thin">
                        {diagReport}
                      </div>

                      <div className="p-3 bg-amber-50/60 dark:bg-amber-950/10 border border-amber-200 dark:border-amber-900/30 rounded-xl text-[11px] text-amber-800 dark:text-amber-300 leading-relaxed flex gap-2">
                        <Sparkles className="size-4 shrink-0 mt-0.5 text-amber-600" />
                        <div>
                          <span className="font-semibold block mb-0.5">گام پیشنهادی بعدی:</span>
                          یک نسخه از این گزارش در سیستم ثبت گردید. جهت دریافت راهکار کامل عملیاتی و مشاوره تلفنی اختصاصی رایگان با کارشناسان موسسه امین، همکاران ما به زودی با شما تماس خواهند گرفت.
                        </div>
                      </div>

                      <Button
                        onClick={handleResetDiagnostic}
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold h-10 text-xs shadow-none mt-2"
                      >
                        متوجه شدم — بازگشت به ورود
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Footer */}
          <p className="text-center text-[11px] text-muted-foreground mt-6">
            سیستم مدیریت ارتباط با مشتری — نسخه ۱.۰ — مؤسسه آموزشی © {currentPersianYear}
          </p>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3">
          <div className="size-16 rounded-full bg-emerald-600 flex items-center justify-center shadow-md">
            <GraduationCap className="size-9 text-white" />
          </div>
          <p className="text-sm font-semibold text-foreground animate-pulse">
            در حال ورود به سیستم...
          </p>
        </div>
      )}
    </div>
  )
}
