'use client'

import { LayoutDashboard, Users, Headphones, BookOpen, Menu } from 'lucide-react'
import { useCRMStore } from '@/lib/store'
import type { ActiveView } from '@/lib/store'

interface NavItem {
  key: ActiveView | 'more'
  label: string
  icon: React.ElementType
}

const navItems: NavItem[] = [
  { key: 'dashboard', label: 'داشبورد', icon: LayoutDashboard },
  { key: 'leads', label: 'لیدها', icon: Users },
  { key: 'sales-panel', label: 'پنل فروش', icon: Headphones },
  { key: 'courses', label: 'دوره‌ها', icon: BookOpen },
  { key: 'more', label: 'بیشتر', icon: Menu },
]

// Map views that aren't directly in the bottom nav to their closest related tab
const viewToNavMap: Partial<Record<ActiveView, string>> = {
  kanban: 'leads',         // Kanban is a leads-related view
  calendar: 'leads',       // Calendar relates to leads
  interactions: 'leads',   // Interactions relate to leads
  enrollments: 'courses',  // Enrollments relate to courses
  users: 'more',           // Users is admin-only
  analytics: 'more',       // Analytics is manager-only
  settings: 'dashboard',   // Settings maps to dashboard nav
}

export default function MobileBottomNav() {
  const { activeView, setActiveView, setSidebarOpen } = useCRMStore()

  const handleClick = (item: NavItem) => {
    if (item.key === 'more') {
      setSidebarOpen(true)
    } else {
      setActiveView(item.key as ActiveView)
    }
  }

  // Determine which nav item should appear active
  const getActiveNavKey = (view: ActiveView): string => {
    if (navItems.some((item) => item.key === view)) return view
    return viewToNavMap[view] || 'more'
  }

  const activeNavKey = getActiveNavKey(activeView)

  return (
    <nav
      dir="rtl"
      className="fixed bottom-0 left-0 right-0 z-40 lg:hidden"
      aria-label="ناوبری موبایل"
    >
      {/* Top shadow */}
      <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      <div className="shadow-[0_-4px_20px_rgba(0,0,0,0.08)] dark:shadow-[0_-4px_20px_rgba(0,0,0,0.3)]">
        <div className="flex items-center justify-around bg-background/80 backdrop-blur-xl border-t border-border/50 px-2 pb-[env(safe-area-inset-bottom,8px)] pt-2">
          {navItems.map((item) => {
            const isActive = item.key === activeNavKey
            const Icon = item.icon

            return (
              <button
                key={item.key}
                onClick={() => handleClick(item)}
                className="flex flex-col items-center justify-center gap-1 min-w-[56px] py-1.5 px-2 rounded-lg transition-colors relative"
                aria-label={item.label}
                aria-current={isActive ? 'page' : undefined}
              >
                {/* Active dot indicator */}
                {isActive && (
                  <span className="absolute -top-0.5 left-1/2 -translate-x-1/2 size-1.5 rounded-full bg-emerald-600" />
                )}
                <Icon
                  className={`size-5 transition-colors ${
                    isActive
                      ? 'text-emerald-600'
                      : 'text-muted-foreground'
                  }`}
                />
                <span
                  className={`text-[10px] leading-tight transition-colors ${
                    isActive
                      ? 'text-emerald-600 font-semibold'
                      : 'text-muted-foreground'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            )
          })}
        </div>
      </div>
    </nav>
  )
}
