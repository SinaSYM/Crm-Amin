import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const session = await getSession(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = request.nextUrl
    const agentId = searchParams.get('agent_id')
    const status = searchParams.get('status')

    const where: Record<string, unknown> = {}

    // Sales Agents can only see their own tasks
    if (session.userRole === 'SALES_AGENT') {
      where.agent_id = session.userId
    } else if (session.userRole === 'STUDENT') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    } else {
      // Managers and admins can filter by agent_id
      if (agentId) {
        where.agent_id = agentId
      }
    }

    if (status) {
      where.status = status
    }

    const tasks = await db.task.findMany({
      where,
      orderBy: { due_date: 'asc' },
      include: {
        lead: {
          select: {
            id: true,
            first_name: true,
            last_name: true,
            phone_number: true,
            status: true,
          },
        },
      },
    })

    return NextResponse.json(tasks)
  } catch (error) {
    console.error('Tasks GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tasks' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getSession(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    if (session.userRole === 'STUDENT') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const { agent_id, lead_id, title, description, due_date } = body

    if (!agent_id || !title || !due_date) {
      return NextResponse.json(
        { error: 'agent_id, title, and due_date are required' },
        { status: 400 }
      )
    }

    // Sales agents can only create tasks for themselves
    if (session.userRole === 'SALES_AGENT' && agent_id !== session.userId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const task = await db.task.create({
      data: {
        agent_id,
        lead_id: lead_id || null,
        title,
        description: description || '',
        due_date: new Date(due_date),
        status: 'PENDING',
      },
    })

    return NextResponse.json(task, { status: 201 })
  } catch (error) {
    console.error('Tasks POST error:', error)
    return NextResponse.json(
      { error: 'Failed to create task' },
      { status: 500 }
    )
  }
}
