import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  // Demo quick-login route — only reachable when DEMO_AUTH=*** is enabled.
  // The real auth flow has `/api/auth/login` + `/api/auth/me` instead.
  if (process.env.DEMO_AUTH !== '1' && process.env.DEMO_AUTH !== 'true') {
    return NextResponse.json({ error: 'Demo auth is disabled' }, { status: 404 })
  }
  try {
    const users = await db.user.findMany({
      where: { is_active: true },
      select: {
        id: true,
        first_name: true,
        last_name: true,
        role: true,
        phone_number: true,
      },
    })
    return NextResponse.json(users)
  } catch (error) {
    console.error('Demo users GET error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch demo users' },
      { status: 500 }
    )
  }
}
